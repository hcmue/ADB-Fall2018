﻿--Cau 1

create database ADBTeam20SpatialDB
go
use ADBTeam20SpatialDB
go
create table ql_thua_dat
(
	MaMD nvarchar(5) primary key,
	ynghiamd nvarchar(50),
	matdoluongnuoc int,
	matdodoanhthu float,
	vitri geometry
)
INSERT INTO ql_thua_dat(MaMD, ynghiamd, matdoluongnuoc, matdodoanhthu, vitri)
VALUES (N'M7',N'Trong lua',75000,250.6,geometry::STGeomFromText('MULTIPOLYGON(((1 0, 1 -4, -2 -5, -2 -1, -1 0 , 1 0)),((5 0, 7 0, 7 -5, 5 -5, 3 -3, 6 -2, 5 0)))', 0))
INSERT INTO ql_thua_dat(MaMD, ynghiamd, matdoluongnuoc, matdodoanhthu, vitri)
VALUES (N'M8', N'Trong cay an qua',45000,350.4,geometry::STGeomFromText('MULTIPOLYGON(((1 -3,3 -3, 3 -5, -2 -5, 1 -4, 1 -3)))',0))
INSERT INTO ql_thua_dat(MaMD, ynghiamd, matdoluongnuoc, matdodoanhthu, vitri)
VALUES (N'M9', N'Trong rau',35000,450.5,geometry::STGeomFromText('MULTIPOLYGON(((1 0, 3 1, 5 0, 5 -2, 3 -3,1 -3, 1 0)))',0))

--Cau 2
--a)
select ql_thua_dat.MaMD, ql_thua_dat.ynghiamd, (ql_thua_dat.vitri.STArea())*ql_thua_dat.matdoluongnuoc as N'Lượng nước tưới tiêu' from ql_thua_dat
--b)
declare @min float
select @min = min(ql_thua_dat.vitri.STArea()) from ql_thua_dat

select * from ql_thua_dat where ql_thua_dat.vitri.STArea() =@min
--c)
DECLARE @kenh geometry = geometry::STGeomFromText('POLYGON ((2 1, 4 1, 4 -5, 2 -5, 2 1))', 0);
select ql_thua_dat.MaMD, ql_thua_dat.vitri.STIntersection(@kenh).STArea()*10000 as DienTichMat from ql_thua_dat

