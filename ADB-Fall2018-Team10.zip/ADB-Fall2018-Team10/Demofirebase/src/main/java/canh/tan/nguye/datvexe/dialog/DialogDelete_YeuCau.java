package canh.tan.nguye.datvexe.dialog;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.data.ViTriHienTai;
import canh.tan.nguye.datvexe.data.model.DatVe;
import canh.tan.nguye.datvexe.data.model.ViTri;
import canh.tan.nguye.datvexe.data.model.YeuCau;
import canh.tan.nguye.datvexe.dialog.adapter.DialogDeleteYeuCau;

public class DialogDelete_YeuCau extends Dialog implements View.OnClickListener {
    private GridView gridView;
    private Context context;
    private List<String> list;
    private DialogDeleteYeuCau deleteYeuCauAdapter;

    private Button button;
    private DatabaseReference reference;
    private FirebaseDatabase database;

    public DialogDelete_YeuCau(@NonNull Context context) {
        super(context);
        this.context = context;

        database = FirebaseDatabase.getInstance();

        setContentView(R.layout.dialog_delete_yeucau);
        getWindow().getAttributes().windowAnimations = R.style.DiaglogAnimationFilter;

        bindingViews();
    }

    private void bindingViews() {
        gridView = findViewById(R.id.grvVTChoNgoi);
        list = new ArrayList<>();
        list = ViTriHienTai.viTriList;
        deleteYeuCauAdapter = new DialogDeleteYeuCau(context, list);
        gridView.setAdapter(deleteYeuCauAdapter);

        button = findViewById(R.id.btnDelete);

        button.setOnClickListener(this);
        addEvents();
    }

    private void addEvents() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnDelete:
                StringBuilder choNgoi = new StringBuilder();
                if (ViTriHienTai.viTriListChon.size() != 0){

                    List<String> list = ViTriHienTai.viTriList;
                    List<String> chon = ViTriHienTai.viTriListChon;

                    if (ViTriHienTai.viTriList.size() == ViTriHienTai.viTriListChon.size()){
                        Toast.makeText(context, ViTriHienTai.viTriList.size() + "", Toast.LENGTH_SHORT).show();
                        reference = database.getReference("YeuCau").child(ViTriHienTai.key_ref);
                        reference.removeValue();
                        dismiss();
                        return;
                    }else {
                        for (int i = ViTriHienTai.viTriList.size() - 1; i >= 0 ; i--) {
                            for (int j = ViTriHienTai.viTriListChon.size() - 1; j >= 0 ; j--) {
                                try {
                                    if (ViTriHienTai.viTriList.get(i).equals(ViTriHienTai.viTriListChon.get(j))){
                                        list.remove(i);
                                        chon.remove(j);
                                    }
                                }catch (IndexOutOfBoundsException e){
                                    Log.e("INDEX_OUT", e.getMessage());
                                }
                            }
                        }
                    }

                    ViTriHienTai.viTriList = list;
                    ViTriHienTai.viTriListChon = chon;

                    for (int i = 0; i < ViTriHienTai.viTriList.size(); i++) {
                        if (i == ViTriHienTai.viTriList.size() - 1){
                            choNgoi.append(ViTriHienTai.viTriList.get(i));
                        }else {
                            choNgoi.append(ViTriHienTai.viTriList.get(i)).append(",");
                        }
                    }

                    if (ViTriHienTai.viTriList.size() != 0){
                        DatVe datVe = new DatVe.Builder()
                                .setIdxe(ViTriHienTai.yeuCau.getThongTinDatVe().getIdxe())
                                .setTenXe(ViTriHienTai.yeuCau.getThongTinDatVe().getTenXe())
                                .setChoNgoi(choNgoi.toString())
                                .setGia(ViTriHienTai.yeuCau.getThongTinDatVe().getGia())
                                .setNgayDat(ViTriHienTai.yeuCau.getThongTinDatVe().getNgayDat())
                                .setThoiGianDi(ViTriHienTai.yeuCau.getThongTinDatVe().getThoiGianDi())
                                .setTuyenDi(ViTriHienTai.yeuCau.getThongTinDatVe().getTuyenDi())
                                .builder();
                        YeuCau yeuCau = new YeuCau.Builder()
                                .setThongTinDatVe(datVe)
                                .setTongTien(String.valueOf(Integer.parseInt(ViTriHienTai.yeuCau.getThongTinDatVe().getGia()) * ViTriHienTai.viTriList.size()))
                                .setSoLuong(ViTriHienTai.viTriList.size() + "")
                                .setTenHangXe(ViTriHienTai.yeuCau.getTenHangXe())
                                .setIdhangXe(ViTriHienTai.yeuCau.getIdhangXe())
                                .setEmail(ViTriHienTai.yeuCau.getEmail())
                                .setTenNguoiNhan(ViTriHienTai.yeuCau.getTenNguoiNhan())
                                .setSoDienThoai(ViTriHienTai.yeuCau.getSoDienThoai())
                                .setTrangThai(ViTriHienTai.yeuCau.getTrangThai())
                                .builder();

                         database.getReference("YeuCau").child(ViTriHienTai.key_ref).setValue(yeuCau);
                         Log.i("DATABASE", database.getReference("/YeuCau/" + ViTriHienTai.key_ref + "/").setValue(yeuCau).toString() + "");
                    }else {
                        Toast.makeText(context, ViTriHienTai.viTriList.size() + "", Toast.LENGTH_SHORT).show();
                        reference = database.getReference("YeuCau").child(ViTriHienTai.key_ref);
                        reference.removeValue();
                        dismiss();
                    }

                    dismiss();

                }else {
                    Toast.makeText(context, "Vui lòng chọn vị trí để xóa!", Toast.LENGTH_SHORT).show();
                }
        }
    }
}
