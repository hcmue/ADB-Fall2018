package canh.tan.nguye.datvexe.admin.login;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import canh.tan.nguye.datvexe.data.model.NguoiDungHienTai;
import canh.tan.nguye.datvexe.view.activity.MainMenuActivity;
import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.manager.ManagerActivity;
import canh.tan.nguye.datvexe.admin.register.RegisterActivity;
import canh.tan.nguye.datvexe.data.model.User;
import canh.tan.nguye.datvexe.dialog.DialogLoading;
import canh.tan.nguye.datvexe.utils.data.DefaultTableFirebase;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity implements OnClickListener {

    TextInputEditText editEmail, editPassword;
    CheckBox chkLogin;
    Button btnLogin, btnRegister;
    Toolbar toolbar;
    DialogLoading dialogLoading;

    FirebaseDatabase database;
    DatabaseReference referenceUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        );

        database = FirebaseDatabase.getInstance();
        referenceUsers = database.getReference(DefaultTableFirebase.USERS);

        addControls();
        addEvents();
    }

    private void addEvents() {
        btnLogin.setOnClickListener(this);
        btnRegister.setOnClickListener(this);
        toolbar.setNavigationOnClickListener(new OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, MainMenuActivity.class);
                Bundle bundle = ActivityOptions.makeCustomAnimation(LoginActivity.this, R.anim.anim_right_left_1, R.anim.anim_right_left_2).toBundle();
                startActivity(intent, bundle);
                finish();
            }
        });
    }

    private void addControls() {
        editEmail = findViewById(R.id.editEmail_login);
        editPassword = findViewById(R.id.editPassword_Login);
        chkLogin = findViewById(R.id.chkRememberLogin_Login);
        btnLogin = findViewById(R.id.btnLogin_Login);
        btnRegister = findViewById(R.id.btnRegister_Login);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        dialogLoading = new DialogLoading(LoginActivity.this);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnLogin_Login:

                if (TextUtils.isEmpty(editEmail.getText().toString())){
                    editEmail.setError(getString(R.string.txt_set_error_email));
                }

                if (TextUtils.isEmpty(editPassword.getText().toString())){
                    editPassword.setError(getString(R.string.txt_set_error_password));
                }

                if (!TextUtils.isEmpty(editPassword.getText().toString()) && !TextUtils.isEmpty(editEmail.getText().toString())){
                    dialogLoading.show();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            referenceUsers.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {

                                    if (dataSnapshot.child(editEmail.getText().toString()).exists()) {
                                        User user = dataSnapshot.child(editEmail.getText().toString()).getValue(User.class);
                                        assert user != null;
                                        if (editPassword.getText().toString().equals(user.getPassword())) {
                                            Intent intent = new Intent(LoginActivity.this, ManagerActivity.class);
                                            NguoiDungHienTai.user = user;
                                            intent.putExtra("USER", NguoiDungHienTai.user);
                                            intent.putExtra("KEY_USER", editEmail.getText().toString());
                                            Bundle bundle = ActivityOptions.makeCustomAnimation(LoginActivity.this, R.anim.anim_left_right_1, R.anim.anim_left_right_2).toBundle();
                                            startActivity(intent, bundle);
                                        }else {
                                            Toast.makeText(LoginActivity.this, "Tài khoản của bạn không đúng!", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                    dialogLoading.dismiss();
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    Toast.makeText(LoginActivity.this, "Lỗi server!", Toast.LENGTH_SHORT).show();
                                    dialogLoading.dismiss();
                                }
                            });
                        }
                    }, 2000);
                }
                break;
            case R.id.btnRegister_Login:
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                Bundle bundle = ActivityOptions.makeCustomAnimation(this, R.anim.anim_left_right_1, R.anim.anim_left_right_2).toBundle();
                startActivity(intent, bundle);
                break;
        }
    }
}

