package canh.tan.nguye.datvexe.view.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.data.GetHangXeHienTai;
import canh.tan.nguye.datvexe.data.GetViTriXe;
import canh.tan.nguye.datvexe.data.NgayHienTai;
import canh.tan.nguye.datvexe.data.SoLuongGhe;
import canh.tan.nguye.datvexe.data.model.DatVe;
import canh.tan.nguye.datvexe.data.model.ViTri;
import canh.tan.nguye.datvexe.data.model.Xe;
import canh.tan.nguye.datvexe.data.model.YeuCau;
import canh.tan.nguye.datvexe.utils.convertData.ConvertDateFormatToString;
import canh.tan.nguye.datvexe.view.adapter.ChooseSeatAdapter;

public class ChooseSeatActivity extends AppCompatActivity {

    Toolbar toolbar;
    Calendar calendarDate = Calendar.getInstance();

    //Component
    TextView txtTenHangXe, txtTenXe, txtTuyenDi,txtThoiGianChay, txtNGayDi;
    GridView gridViewTang1, gridViewTang2;
    Button btnTiepTuc, btnThayDoiThoiGian;

    Xe xe;
    String idXe, idHangXe;
    String tenHangXe;
    DatVe datVe;
    YeuCau yeuCau;

    TextView txtSuKien;
    String suKien;

    List<ViTri> arrViTriChoNgoi1;
    List<ViTri> arrViTriChoNgoi2;
    ChooseSeatAdapter adapter1,adapter2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_seat);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        suKien = getIntent().getStringExtra("SUKIEN");
        addControls();
        addEvents();

    }

    private void addEvents() {
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnTiepTuc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = 0;
                if (SoLuongGhe.viTriChoNgoi.isEmpty()) {
                    Toast.makeText(ChooseSeatActivity.this, "Vui lòng chọn vị trí đặt vé!", Toast.LENGTH_SHORT).show();
                }else {
                    String choNgoi = "";
                    int s = SoLuongGhe.viTriChoNgoi.size();
                    int n = 1;
                    for (ViTri item : SoLuongGhe.viTriChoNgoi){
                        if (s == n){
                            choNgoi = choNgoi + item.getTenViTri();
                        }else {
                            choNgoi = choNgoi + item.getTenViTri() + ",";
                            n++;
                        }

                    }

                    datVe = new DatVe.Builder()
                            .setIdxe(idXe)
                            .setTenXe(xe.getTenXe())
                            .setTuyenDi(xe.getNoiDi() + " - " + xe.getNoiDen())
                            .setThoiGianDi(txtThoiGianChay.getText().toString())
                            .setNgayDat(txtNGayDi.getText().toString())
                            .setGia(xe.getGiaTien())
                            .setChoNgoi(choNgoi)
                            .builder();


                    yeuCau = new YeuCau.Builder()
                            .setThongTinDatVe(datVe)
                            .setIdhangXe(idHangXe)
                            .setSoLuong(s + "")
                            .setTenHangXe(tenHangXe)
                            .setTongTien(String.valueOf(s * Integer.parseInt(datVe.getGia())) + "")
                            .builder();

                    Intent intent = new Intent(ChooseSeatActivity.this, ConfirmInfoCustomerActivity.class);
                    intent.putExtra("DAT_VE_LIST", yeuCau);
                    startActivity(intent);
                    finish();
                    SoLuongGhe.viTriChoNgoi = null;
                }
            }
        });
    }

    private void addControls() {
        if (xe == null){
            xe = (Xe) getIntent().getSerializableExtra("XeHienTai");
        }

        if (idXe == null){
            idXe = getIntent().getStringExtra("IDXe");
            GetHangXeHienTai.idXe = idXe;
        }

        if (tenHangXe == null){
            tenHangXe = getIntent().getStringExtra("TenHangXe");
        }

        if (idHangXe == null){
            idHangXe = getIntent().getStringExtra("IDHangXe");
            GetHangXeHienTai.idHangXe = idHangXe;
        }

        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        txtSuKien = findViewById(R.id.txtSuKien);
        txtTenHangXe = findViewById(R.id.txtTenHangXe_ChooseSeat);
        txtTenXe = findViewById(R.id.txtTenXe_ChooseSeat);
        txtTuyenDi = findViewById(R.id.txtHuongDi_ChooseSeat);
        txtThoiGianChay = findViewById(R.id.txtThoiGian_ChooseSeat);
        txtNGayDi = findViewById(R.id.txtDate_ChooseSeat);
        gridViewTang1 = findViewById(R.id.grvVTChoNgoiTang1_ChooseSeat);
        gridViewTang2 = findViewById(R.id.grvVTChoNgoiTang2_ChooseSeat);
        btnTiepTuc = findViewById(R.id.btnTiepTuc_ChooseSeat);
        btnThayDoiThoiGian = findViewById(R.id.btnThoiGian_ChooseSeat);

        txtSuKien.setText(suKien);

        getDatas();
        setDate();

        arrViTriChoNgoi1 = new ArrayList<>();
        arrViTriChoNgoi2 = new ArrayList<>();

        arrViTriChoNgoi1 = xe.getTang1();
        arrViTriChoNgoi2 = xe.getTang2();




        adapter1 = new ChooseSeatAdapter(ChooseSeatActivity.this, arrViTriChoNgoi1);
        gridViewTang1.setAdapter(adapter1);

        adapter2 = new ChooseSeatAdapter(ChooseSeatActivity.this, arrViTriChoNgoi2);

        gridViewTang2.setAdapter(adapter2);
    }

    private void getDatas() {
        txtTenHangXe.setText(tenHangXe);
        txtTenXe.setText(xe.getTenXe());
        txtTuyenDi.setText(xe.getNoiDi() + " - " + xe.getNoiDen());
        txtThoiGianChay.setText(xe.getThoiGianBDDi());
    }

    private void setDate() {
        txtNGayDi.setText(ConvertDateFormatToString.processFormat(ConvertDateFormatToString.convertDateToString()));

        Date chosenDate = calendarDate.getTime();

        DateFormat df = DateFormat.getDateInstance(DateFormat.LONG, Locale.US);
        String formattedDate = df.format(chosenDate);
        txtNGayDi.setText(formattedDate);

        NgayHienTai.date = txtNGayDi.getText().toString();

        btnThayDoiThoiGian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Initialize a new date picker dialog fragment
                DialogFragment dFragment = new DatePickerFragment();

                // Show the date picker dialog fragment
                dFragment.show(getFragmentManager(), "Date Picker");
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @SuppressLint("ValidFragment")
    public class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog dpd = new DatePickerDialog(getActivity(),
                    AlertDialog.THEME_HOLO_LIGHT,this,year,month,day);

            /*calendar.add(Calendar.DATE, 3);
            dpd.getDatePicker().setMaxDate(calendar.getTimeInMillis());
            calendar.add(Calendar.DATE, -6);*/

            // Set the Calendar new date as minimum date of date picker
            dpd.getDatePicker().setMinDate(calendar.getTimeInMillis());

            return dpd;
        }

        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            //TextView txt = getActivity().findViewById(R.id.txtDate_ChooseSeat);

            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(0);
            cal.set(year, month, dayOfMonth, 0, 0, 0);
            Date chosenDate = cal.getTime();
            calendarDate = cal;

            // Format the date using style and locale
            DateFormat df = DateFormat.getDateInstance(DateFormat.LONG, Locale.US);
            String formattedDate = df.format(chosenDate);

            // Display the chosen date to app interface
            ChooseSeatActivity.this.txtNGayDi.setText(formattedDate);
            NgayHienTai.date = txtNGayDi.getText().toString();
            adapter1.notifyDataSetChanged();
            adapter2.notifyDataSetChanged();
        }
    }

}

