package canh.tan.nguye.datvexe.dialog;

import android.app.ActivityOptions;
import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TextInputEditText;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.utils.convertData.ConvertDateFormatToString;

public class DialogFilter extends BaseDialog {
    TextView txtNote;
    TextInputEditText editPositionStart, editPositionEnd;
    TextView editDate;
    ImageButton ibtnDate;
    Button btnSearch;

    Context context;

    public DialogFilter(@NonNull Context context) {
        super(context);
        this.context = context;

        setContentView(R.layout.dialog_filter_car);
        getWindow().getAttributes().windowAnimations = R.style.DiaglogAnimationFilter;

        bindingViews();
    }

    private void bindingViews() {
        txtNote = findViewById(R.id.txtNote_DialogFilter);
        editPositionStart = findViewById(R.id.editSearchPositionStart_DialogFilter);
        editPositionEnd = findViewById(R.id.editSearchPositionEnd_DialogFilter);
        editDate = findViewById(R.id.editDayExchange_DialogFilter);
        ibtnDate = findViewById(R.id.ibtnDate_DialogFilter);
        btnSearch = findViewById(R.id.btnSearch_DialogFilter);

        editDate.setFocusable(false);


        addEvents();
    }

    private void addEvents() {
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Filter successfull!y", Toast.LENGTH_SHORT).show();
            }
        });

        editDate.setText(ConvertDateFormatToString.processFormat(ConvertDateFormatToString.convertDateToString()));

        editDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        editDate.setText((dayOfMonth) + "/" + (month + 1) + "/" + year);
                    }
                };

                int day = 0, mon = 0, year = 0;
                DatePickerDialog pic = null;
                if (!TextUtils.isEmpty(editDate.getText().toString())) {
                    String date = editDate.getText() + "";
                    String strArrtmp[] = date.split("/");
                    day = Integer.parseInt(strArrtmp[0]);
                    mon = Integer.parseInt(strArrtmp[1]) - 1;
                    year = Integer.parseInt(strArrtmp[2]);
                    pic = new DatePickerDialog(
                            context, callback, year, mon, day);
                } else {
                    pic = new DatePickerDialog(
                            context, callback, 2015, 01, 01);
                }

                pic.show();
            }
        });

        ibtnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        editDate.setText((dayOfMonth) + "/" + (month + 1) + "/" + (year));
                    }
                };

                DatePickerDialog pickerDialog = null;
                String date = editDate.getText() + "";
                String tempDay[] = date.split("/");
                int dayOfMonth = Integer.parseInt(tempDay[0]);
                int monthOfYear = Integer.parseInt(tempDay[1]) - 1;
                int year = Integer.parseInt(tempDay[2]);
                pickerDialog = new DatePickerDialog(context, callback, year, monthOfYear, dayOfMonth);
                pickerDialog.show();
            }
        });
    }
}
