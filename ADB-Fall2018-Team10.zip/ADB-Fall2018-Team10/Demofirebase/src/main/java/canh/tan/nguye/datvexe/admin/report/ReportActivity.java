package canh.tan.nguye.datvexe.admin.report;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.data.Status;
import canh.tan.nguye.datvexe.data.model.YeuCau;

public class ReportActivity extends AppCompatActivity {

    BarChart lineChart;
    FirebaseDatabase database;
    DatabaseReference reference;
    List<YeuCau> yeuCaus;

    int chua_xac_nhan = 0;
    int xac_nhan = 0;
    int da_huy = 0;

    String idHangXe;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        database = FirebaseDatabase.getInstance();
        reference = database.getReference("YeuCau");
        idHangXe = getIntent().getStringExtra("HangXeID");
        yeuCaus = new ArrayList<>();

        button = findViewById(R.id.btn_change_info);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initDataFirebase();
        addCOntrols();
    }

    private void initDataFirebase() {

        reference.orderByChild("idhangXe").equalTo(idHangXe).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot item : dataSnapshot.getChildren()){
                    YeuCau yeuCau = item.getValue(YeuCau.class);
                    if (yeuCau != null) {
                        yeuCaus.add(yeuCau);
                    }else {
                        Toast.makeText(ReportActivity.this, "NULL", Toast.LENGTH_SHORT).show();
                    }
                }


                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                cal.setTimeInMillis(0);
                cal.set(year, month, day, 0, 0, 0);
                Date chosenDate = cal.getTime();

                // Format the date using style and locale
                DateFormat df = DateFormat.getDateInstance(DateFormat.LONG, Locale.US);
                String formattedDate = df.format(chosenDate);

                try {
                    chosenDate = df.parse(formattedDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                Log.i("DATE", chosenDate + " ------- "  + formattedDate);
                
                for (int j = 0 ; j < yeuCaus.size(); j++){
                    try {
                        Date temp = df.parse(yeuCaus.get(j).getThongTinDatVe().getNgayDat());

                        if (temp.getDay() < chosenDate.getDay() && !yeuCaus.get(j).getTrangThai().equals(Status.XAC_NHAN)){
                            da_huy++;
                        }
                        if (yeuCaus.get(j).getTrangThai().equals(Status.XAC_NHAN)){
                            xac_nhan++;
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                }

                chua_xac_nhan = yeuCaus.size() - (da_huy + xac_nhan);

                lineChart = findViewById(R.id.chart);
                final int[] sum = new int[3];



                ArrayList<BarEntry> entries = new ArrayList<>();
                entries.add(new BarEntry(xac_nhan, 0));
                entries.add(new BarEntry(chua_xac_nhan, 1));
                entries.add(new BarEntry(da_huy, 2));

                BarDataSet dataSet = new BarDataSet(entries, "Màu sắc");

                ArrayList<String> labels = new ArrayList<String>();
                labels.add("Đã xác nhận");
                labels.add("Đang chờ");
                labels.add("Đã Hủy");


                dataSet.setColors(ColorTemplate.COLORFUL_COLORS);

                BarData data = new BarData(labels ,dataSet);

                lineChart.setData(data);

                lineChart.animateY(2000);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void addCOntrols() {

    }
}
