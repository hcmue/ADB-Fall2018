package canh.tan.nguye.datvexe.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.LinearLayout;

import canh.tan.nguye.datvexe.R;

public class BaseDialog extends Dialog{
    Context context;

    public BaseDialog(@NonNull Context context) {
        super(context);
        this.context = context;

        setCancelable(true);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }
}
