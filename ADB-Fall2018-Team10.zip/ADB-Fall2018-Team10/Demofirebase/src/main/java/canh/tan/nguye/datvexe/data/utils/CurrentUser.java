package canh.tan.nguye.datvexe.data.utils;

import canh.tan.nguye.datvexe.data.model.User;

public class CurrentUser {
    public static User user;

    public static boolean verifyUser(){
        if (user != null){
            return true;
        }

        return false;
    }
}
