package canh.tan.nguye.datvexe.admin.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.manager.CustomerOfGarageActivity;

public class CustomerManagerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public TextView txtTenXe, txtTuyenDi, txtTenKhachHang, txtViTri, txtTongTien, txtThoiGianDi, txtNgayDi, txtSoDienThoaiKH, txtTrangThai_SeatChooseCustomer_Manager;
    public Button btnHuyCho, btnGoiDien, btnXacNhan;

    private ItemOnClickListenner listenner;

    public CustomerManagerViewHolder(View itemView) {
        super(itemView);
        txtTenXe = itemView.findViewById(R.id.txtTenXe_SeatChooseCustomer_Manager);
        txtTuyenDi = itemView.findViewById(R.id.txtTuyenDi_SeatChooseCustomer_Manager);
        txtTenKhachHang = itemView.findViewById(R.id.txtTenKhachHang_SeatChooseCustomer_Manager);
        txtViTri = itemView.findViewById(R.id.txtViTri_SeatChooseCustomer_Manager);
        txtTongTien = itemView.findViewById(R.id.txtTongTien_SeatChooseCustomer_Manager);
        txtThoiGianDi = itemView.findViewById(R.id.txtThoiGianDi_SeatChooseCustomer_Manager);
        txtNgayDi = itemView.findViewById(R.id.txtNgayDi_SeatChooseCustomer_Manager);
        txtSoDienThoaiKH = itemView.findViewById(R.id.txtSoDienThoaiKhachHang_SeatChooseCustomer_Manager);
        txtTrangThai_SeatChooseCustomer_Manager = itemView.findViewById(R.id.txtTrangThai_SeatChooseCustomer_Manager);
        btnHuyCho = itemView.findViewById(R.id.btnHuyCho_SeatChooseCustomer_Manager);
        btnGoiDien = itemView.findViewById(R.id.btnGoiDien_SeatChooseCustomer_Manager);
        btnXacNhan = itemView.findViewById(R.id.btnXacNhan);

        btnHuyCho.setOnClickListener(this);
        btnGoiDien.setOnClickListener(this);
    }

    public CustomerManagerViewHolder setListenner(ItemOnClickListenner listenner) {
        this.listenner = listenner;
        return this;
    }

    @Override
    public void onClick(View v) {
        listenner.onClick(v, getAdapterPosition(), false);
    }
}
