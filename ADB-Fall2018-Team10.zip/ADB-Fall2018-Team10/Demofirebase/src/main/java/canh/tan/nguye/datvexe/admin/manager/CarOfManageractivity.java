package canh.tan.nguye.datvexe.admin.manager;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.List;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.adapter.CarManagerViewHolder;
import canh.tan.nguye.datvexe.admin.adapter.ItemOnClickListenner;
import canh.tan.nguye.datvexe.admin.addCar.AddCarActivity;
import canh.tan.nguye.datvexe.admin.updateCar.UpdateCarActivity;
import canh.tan.nguye.datvexe.data.model.Xe;

public class CarOfManageractivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference referenceCar;
    FirebaseStorage storage;
    StorageReference storageXe;

    List<Xe> list;
    FirebaseRecyclerOptions<Xe> options;
    FirebaseRecyclerAdapter<Xe, CarManagerViewHolder> adapter;
    RecyclerView lvCarCustomer_Manager;
    LinearLayout llayout_add_car, layoutProgress_Manager;

    String idHangXe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_of_manageractivity);

        database = FirebaseDatabase.getInstance();
        referenceCar = database.getReference("Xe");
        storage = FirebaseStorage.getInstance();

        idHangXe = getIntent().getStringExtra("HangXeID");

        addControls();
    }

    private void addControls() {
        lvCarCustomer_Manager = findViewById(R.id.lvCarCustomer_Manager);
        lvCarCustomer_Manager.setHasFixedSize(true);
        lvCarCustomer_Manager.setLayoutManager(new LinearLayoutManager(CarOfManageractivity.this, LinearLayout.VERTICAL, false));
        llayout_add_car = findViewById(R.id.llayout_add_car);
        layoutProgress_Manager = findViewById(R.id.layoutProgress_Manager);
        layoutProgress_Manager.setVisibility(View.GONE);

        llayout_add_car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CarOfManageractivity.this, AddCarActivity.class);
                intent.putExtra("HangXeID", idHangXe);
                startActivity(intent);
            }
        });

        getDatFirebase();
    }

    private void getDatFirebase() {
        Query query = database.getReference().child("Xe").orderByChild("idHX").equalTo(idHangXe);
        options = new FirebaseRecyclerOptions.Builder<Xe>()
                .setQuery(query, Xe.class)
                .build();


        adapter = new FirebaseRecyclerAdapter<Xe, CarManagerViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final CarManagerViewHolder holder, final int position, @NonNull final Xe model) {
                Picasso.get().load(model.getImgHinh())
                        .error(R.drawable.ic_car)
                        .centerCrop()
                        .resize(200, 200)
                        .placeholder(R.drawable.ic_car)
                        .into(holder.car_img);

                holder.car_txt_name.setText(model.getTenXe());
                holder.car_txt_route.setText(model.getNoiDi() + " - " + model.getNoiDen());
                holder.car_txt_time_start.setText(model.getThoiGianBDDi());
                holder.car_txt_fare.setText(model.getGiaTien());
                holder.setListenner(new ItemOnClickListenner() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        Toast.makeText(CarOfManageractivity.this, holder.car_txt_name.getText() + " ", Toast.LENGTH_SHORT).show();
                    }
                });

                holder.delete_car.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(CarOfManageractivity.this);
                        builder.setMessage("Bạn có chắc chắn muốn xóa không?");
                        builder.setCancelable(false);
                        builder.setPositiveButton("Đồng ý", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                storageXe = storage.getReferenceFromUrl(model.getImgHinh());
                                storageXe.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        referenceCar =  database.getReference().child("Xe").child(adapter.getRef(position).getKey()+"");
                                        referenceCar.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                Toast.makeText(CarOfManageractivity.this, "Bạn đã xóa thành công!", Toast.LENGTH_SHORT).show();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Log.e("ERROR_DATA", e.getMessage() + "");
                                            }
                                        });
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e("ERROR_STORAGE", e.getMessage() + "\n" + model.getImgHinh());
                                    }
                                });
                            }
                        });

                        builder.setNegativeButton("Trở về", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                        builder.show();
                    }
                });

                holder.ibtnEditCar_Manager.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(CarOfManageractivity.this, UpdateCarActivity.class);
                        intent.putExtra("CAR_DATA", model);
                        intent.putExtra("KEY_CAR", adapter.getRef(position).getKey());
                        startActivity(intent);
                    }
                });
            }

            @NonNull
            @Override
            public CarManagerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new CarManagerViewHolder(LayoutInflater.from(CarOfManageractivity.this).inflate(R.layout.item_car_manager, parent, false));
            }
        };
        lvCarCustomer_Manager.setAdapter(adapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        layoutProgress_Manager.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                layoutProgress_Manager.setVisibility(View.GONE);
                adapter.startListening();
            }
        }, 1500);
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
