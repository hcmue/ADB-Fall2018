package canh.tan.nguye.datvexe.data.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;
import java.util.List;

import canh.tan.nguye.datvexe.data.model.DatVe;

public class Database extends SQLiteAssetHelper {
    private static final String DB_NAME = "SQLiteDB.db";
    private static final int DB_VERSION = 1;

    public Database(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    public List<DatVe> getCart(){
        SQLiteDatabase database = getReadableDatabase();
        SQLiteQueryBuilder builder = new SQLiteQueryBuilder();

        String[] sqlSelect = {
                "IDXe",
                "TenXe",
                "ChoNgoi",
                "Gia",
                "NgayDat",
                "ThoiGianDi"
        };

        String sqlTableChiTiet = "ThongTinDatVe";
        builder.setTables(sqlTableChiTiet);

        Cursor cursor = builder.query(database, sqlSelect, null, null, null, null, null);

        final List<DatVe> ketQua = new ArrayList<>();

        if(cursor.moveToFirst()){
            do{
                DatVe datVe = new DatVe.Builder()
                        .setIdxe(cursor.getString(cursor.getColumnIndex("IDXe")))
                        .setTenXe(cursor.getString(cursor.getColumnIndex("TenXe")))
                        .setChoNgoi(cursor.getString(cursor.getColumnIndex("ChoNgoi")))
                        .setGia(cursor.getString(cursor.getColumnIndex("Gia")))
                        .setNgayDat(cursor.getString(cursor.getColumnIndex("NgayDat")))
                        .setThoiGianDi(cursor.getString(cursor.getColumnIndex("ThoiGianDi")))
                        .builder();

                ketQua.add(datVe);
            }while (cursor.moveToNext());
        }
        return ketQua;
    }

    public void addToCart(DatVe datVe){
        SQLiteDatabase database = getReadableDatabase();
        String query = String.format("INSERT INTO TongTinVeXe(IDXe, TenXe, ChoNgoi, Gia, NgayDat, ThoiGianDi) " +
                "VALUES('%s', '%s', '%s', '%s', '%s', '%s');",
                datVe.getIdxe(),
                datVe.getTenXe(),
                datVe.getChoNgoi(),
                datVe.getGia(),
                datVe.getNgayDat(),
                datVe.getThoiGianDi());

        database.execSQL(query);
    }

    public void clearCart(){
        SQLiteDatabase database = getReadableDatabase();
        String query = String.format("DELETE FROM ThongTinVeXe");
        database.execSQL(query);
    }
}
