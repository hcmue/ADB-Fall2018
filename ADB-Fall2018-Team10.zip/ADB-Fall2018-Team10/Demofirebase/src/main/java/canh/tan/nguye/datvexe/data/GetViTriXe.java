package canh.tan.nguye.datvexe.data;

import java.util.ArrayList;
import java.util.List;

public class GetViTriXe {

    public static List<String> getViTri(){
        List<String> arrViTri = new ArrayList<>();
        arrViTri.add("A1");
        arrViTri.add("B1");
        arrViTri.add("C1");
        arrViTri.add("A2");
        arrViTri.add("B2");
        arrViTri.add("C2");
        arrViTri.add("A3");
        arrViTri.add("B3");
        arrViTri.add("C3");
        arrViTri.add("A4");
        arrViTri.add("B4");
        arrViTri.add("C4");
        arrViTri.add("A5");
        arrViTri.add("B5");
        arrViTri.add("C5");
        arrViTri.add("A6");
        arrViTri.add("B6");
        arrViTri.add("C6");

        arrViTri.add("A7");
        arrViTri.add("B7");
        arrViTri.add("C7");
        arrViTri.add("A8");
        arrViTri.add("B8");
        arrViTri.add("C8");
        arrViTri.add("A9");
        arrViTri.add("B9");
        arrViTri.add("C9");
        arrViTri.add("A10");
        arrViTri.add("B10");
        arrViTri.add("C10");
        arrViTri.add("A11");
        arrViTri.add("B11");
        arrViTri.add("C11");
        arrViTri.add("A12");
        arrViTri.add("B12");
        arrViTri.add("C12");

        arrViTri.add("A13");
        arrViTri.add("B13");
        arrViTri.add("C13");
        arrViTri.add("A14");
        arrViTri.add("B14");
        arrViTri.add("C14");
        arrViTri.add("A15");
        arrViTri.add("B15");
        arrViTri.add("C15");
        arrViTri.add("A16");
        arrViTri.add("B16");
        arrViTri.add("C16");
        arrViTri.add("A17");
        arrViTri.add("B17");
        arrViTri.add("C17");
        arrViTri.add("A18");
        arrViTri.add("B18");
        arrViTri.add("C18");

        arrViTri.add("A19");
        arrViTri.add("B19");
        arrViTri.add("C19");
        arrViTri.add("A20");
        arrViTri.add("B20");
        arrViTri.add("C20");
        arrViTri.add("A21");
        arrViTri.add("B21");
        arrViTri.add("C21");
        arrViTri.add("A22");
        arrViTri.add("B22");
        arrViTri.add("C22");
        arrViTri.add("A23");
        arrViTri.add("B23");
        arrViTri.add("C23");
        arrViTri.add("A24");
        arrViTri.add("B24");
        arrViTri.add("C24");

        arrViTri.add("A25");
        arrViTri.add("B25");
        arrViTri.add("C25");
        arrViTri.add("A26");
        arrViTri.add("B26");
        arrViTri.add("C26");
        arrViTri.add("A27");
        arrViTri.add("B27");
        arrViTri.add("C27");
        arrViTri.add("A28");
        arrViTri.add("B28");
        arrViTri.add("C28");
        arrViTri.add("A29");
        arrViTri.add("B29");
        arrViTri.add("C29");
        arrViTri.add("A30");
        arrViTri.add("B30");
        arrViTri.add("C30");

        arrViTri.add("A31");
        arrViTri.add("B31");
        arrViTri.add("C31");
        arrViTri.add("A32");
        arrViTri.add("B32");
        arrViTri.add("C32");
        arrViTri.add("A33");
        arrViTri.add("B33");
        arrViTri.add("C33");
        arrViTri.add("A34");
        arrViTri.add("B34");
        arrViTri.add("C34");
        arrViTri.add("A35");
        arrViTri.add("B35");
        arrViTri.add("C35");
        arrViTri.add("A36");
        arrViTri.add("B36");
        arrViTri.add("C36");

        arrViTri.add("A37");
        arrViTri.add("B37");
        arrViTri.add("C37");
        arrViTri.add("A38");
        arrViTri.add("B38");
        arrViTri.add("C38");
        arrViTri.add("A39");
        arrViTri.add("B39");
        arrViTri.add("C39");
        arrViTri.add("A40");
        arrViTri.add("B40");
        arrViTri.add("C40");
        arrViTri.add("A41");
        arrViTri.add("B41");
        arrViTri.add("C41");
        arrViTri.add("A42");
        arrViTri.add("B42");
        arrViTri.add("C42");



        return arrViTri;
    }

}
