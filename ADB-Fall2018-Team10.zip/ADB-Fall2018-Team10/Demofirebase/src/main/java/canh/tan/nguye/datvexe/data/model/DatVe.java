package canh.tan.nguye.datvexe.data.model;

import com.google.firebase.database.Exclude;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class DatVe implements Serializable{
    private String idxe;
    private String tenXe;
    private String choNgoi;
    private String tuyenDi;
    private String gia;
    private String ngayDat;
    private String thoiGianDi;

    public DatVe() {
    }

    public DatVe(Builder builder) {
        this.idxe = builder.idxe;
        this.tenXe = builder.tenXe;
        this.choNgoi = builder.choNgoi;
        this.tuyenDi = builder.tuyenDi;
        this.gia = builder.gia;
        this.ngayDat = builder.ngayDat;
        this.thoiGianDi = builder.thoiGianDi;
    }

    @Exclude
    public Map<String , String> toMap(){
        HashMap<String, String> map = new HashMap<>();
        map.put("idxe", getIdxe());
        map.put("tenXe", getTenXe());
        map.put("choNgoi", getChoNgoi());
        map.put("tuyenDi", getTuyenDi());
        map.put("gia", getGia());
        map.put("ngayDat", getNgayDat());
        map.put("thoiGianDi", getThoiGianDi());

        return map;
    }


    public String getIdxe() {
        return idxe;
    }

    public String getTenXe() {
        return tenXe;
    }

    public String getChoNgoi() {
        return choNgoi;
    }

    public String getTuyenDi() {
        return tuyenDi;
    }

    public String getGia() {
        return gia;
    }

    public String getNgayDat() {
        return ngayDat;
    }

    public String getThoiGianDi() {
        return thoiGianDi;
    }

    public static class Builder{
        private String idxe;
        private String tenXe;
        private String choNgoi;
        private String tuyenDi;
        private String gia;
        private String ngayDat;
        private String thoiGianDi;

        public Builder() {
        }

        public Builder(String idxe, String tenXe, String choNgoi, String tuyenDi, String gia, String ngayDat, String thoiGianDi) {
            this.idxe = idxe;
            this.tenXe = tenXe;
            this.choNgoi = choNgoi;
            this.tuyenDi = tuyenDi;
            this.gia = gia;
            this.ngayDat = ngayDat;
            this.thoiGianDi = thoiGianDi;
        }

        public Builder setIdxe(String idxe) {
            this.idxe = idxe;
            return this;
        }

        public Builder setTenXe(String tenXe) {
            this.tenXe = tenXe;
            return this;
        }

        public Builder setChoNgoi(String choNgoi) {
            this.choNgoi = choNgoi;
            return this;
        }

        public Builder setTuyenDi(String tuyenDi) {
            this.tuyenDi = tuyenDi;
            return this;
        }

        public Builder setGia(String gia) {
            this.gia = gia;
            return this;
        }

        public Builder setNgayDat(String ngayDat) {
            this.ngayDat = ngayDat;
            return this;
        }

        public Builder setThoiGianDi(String thoiGianDi) {
            this.thoiGianDi = thoiGianDi;
            return this;
        }

        public DatVe builder(){
            return new DatVe(this);
        }
    }
}
