package canh.tan.nguye.datvexe.admin.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import java.util.Objects;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.manager.CustomerOfGarageActivity;
import canh.tan.nguye.datvexe.data.model.HangXe;
import canh.tan.nguye.datvexe.data.model.User;
import canh.tan.nguye.datvexe.data.model.YeuCau;
import canh.tan.nguye.datvexe.utils.data.DefaultTableFirebase;
import canh.tan.nguye.datvexe.admin.adapter.CustomerManagerViewHolder;
import canh.tan.nguye.datvexe.view.activity.CarListActivity;
import canh.tan.nguye.datvexe.view.activity.MainMenuActivity;
import canh.tan.nguye.datvexe.view.adapter.ItemOnClickListenner;
import canh.tan.nguye.datvexe.view.adapter.MainMenuViewHolder;

public class CustomerManagerFragment extends Fragment {

    FirebaseDatabase database;
    FirebaseRecyclerOptions<HangXe> options;
    FirebaseRecyclerAdapter<HangXe, MainMenuViewHolder> adapter;

    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;

    ProgressBar progressBar;

    String KEY_USER;
    User user;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_customer_manager, container, false);

        database = FirebaseDatabase.getInstance();

        KEY_USER = getActivity().getIntent().getStringExtra("KEY_USER");

        //progressBar = view.findViewById(R.id.progress);
        getFirebaseDatas(view);

        return view;
    }

    private void getFirebaseDatas(View view) {
        recyclerView = view.findViewById(R.id.recyclerView_CustomerManager);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        Query query = database.getReference().child("HangXe");
        options = new FirebaseRecyclerOptions.Builder<HangXe>()
                .setQuery(query, HangXe.class)
                .build();

        /*adapter = new FirebaseRecyclerAdapter<YeuCau, CustomerManagerViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final CustomerManagerViewHolder holder, int position, @NonNull YeuCau model) {
                //Toast.makeText(getActivity(), model.getTenNguoiNhan() + " - " + model.getTongTien(), Toast.LENGTH_SHORT).show();
                holder.txtTenXe.setText(model.getDanhSachThongTinVe().get(position).getTenXe());
                holder.txtNgayDi.setText(model.getDanhSachThongTinVe().get(position).getNgayDat());
                holder.txtSoDienThoaiKH.setText(model.getSoDienThoai());
                holder.txtTenKhachHang.setText(model.getTenNguoiNhan());
                holder.txtThoiGianDi.setText(model.getDanhSachThongTinVe().get(position).getThoiGianDi());
                holder.txtTuyenDi.setText(model.getDanhSachThongTinVe().get(position).getTuyenDi());
                holder.txtViTri.setText(model.getDanhSachThongTinVe().get(position).getChoNgoi());
                holder.txtTongTien.setText(model.getTongTien());;

                holder.btnGoiDien.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent callIntent =new Intent(Intent.ACTION_CALL);
                        callIntent.setData(Uri.parse("tel:" + holder.txtSoDienThoaiKH.getText().toString()));
                        startActivity(callIntent);
                    }
                });
            }

            @NonNull
            @Override
            public CustomerManagerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new CustomerManagerViewHolder(LayoutInflater.from(getActivity()).inflate(R.layout.item_customer_manager, parent, false));
            }
        };*/

        adapter = new FirebaseRecyclerAdapter<HangXe, MainMenuViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull MainMenuViewHolder holder, int position, @NonNull final HangXe model) {
                Picasso.get().load(model.getImgHinh()).into(holder.img);
                holder.txtTenHang.setText(model.getTenHangXe());
                holder.txtDiaChi.setText(model.getDiaChi());
                holder.txtNoiDung.setText(model.getNoiDung());

                if (holder.txtTenHang.length() >= 50){
                    String temp = holder.txtTenHang.getText().toString();
                    holder.txtTenHang.setText(temp.substring(0, 50) + "...");
                }

                if (holder.txtDiaChi.length() >= 50){
                    String temp = holder.txtDiaChi.getText().toString();
                    holder.txtDiaChi.setText(temp.substring(0, 50) + "...");
                }

                if (holder.txtNoiDung.length() >= 100){
                    String temp = holder.txtNoiDung.getText().toString();
                    holder.txtNoiDung.setText(temp.substring(0, 100) + "...");
                }

                holder.setListenner(new ItemOnClickListenner() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        Intent carList = new Intent(getContext(), CustomerOfGarageActivity.class);
                        carList.putExtra("HangXeID", adapter.getRef(position).getKey());
                        carList.putExtra("TenHangXe", model.getTenHangXe());
                        startActivity(carList);

                    }
                });
            }

            @NonNull
            @Override
            public MainMenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new MainMenuViewHolder(LayoutInflater.from(getContext()).inflate(R.layout.item_hang_xe, parent, false));
            }
        };

        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
