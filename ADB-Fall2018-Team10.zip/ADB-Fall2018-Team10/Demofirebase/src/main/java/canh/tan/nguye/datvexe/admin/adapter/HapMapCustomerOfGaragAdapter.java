/*
package canh.tan.nguye.datvexe.admin.adapter;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.manager.CustomerOfGarageActivity;
import canh.tan.nguye.datvexe.data.ViTriHienTai;
import canh.tan.nguye.datvexe.data.model.DatVe;
import canh.tan.nguye.datvexe.data.model.ViTri;
import canh.tan.nguye.datvexe.dialog.DialogDelete_YeuCau;

public class HapMapCustomerOfGaragAdapter extends RecyclerView.Adapter<HapMapCustomerOfGaragAdapter.ViewHolder>{
    private Context context;
    private List<HashMap<String, Object>> list;
    private String key;

    public HapMapCustomerOfGaragAdapter(Context context, List<HashMap<String, Object>> list, String key) {
        this.context = context;
        this.list = list;
        this.key = key;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_customer_manager, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ViTriHienTai.key_ref = key;
        ViTriHienTai.tongTien = (String) list.get(position).get("tongTien");
        HashMap<String, Object> model = list.get(position);

        int s = (int) model.get("danhSachThongTinVe");
        n = 0;
        holder.txtViTri.setText("");
        Toast.makeText(CustomerOfGarageActivity.this, s + "", Toast.LENGTH_SHORT).show();

        n++;

        holder.txtSoDienThoaiKH.setText(model.getSoDienThoai());
        holder.txtTenKhachHang.setText(model.getTenNguoiNhan());
        holder.txtTongTien.setText(model.getTongTien());
        holder.txtTenXe.setText(item.getTenXe());
        holder.txtNgayDi.setText(item.getNgayDat());

        holder.txtThoiGianDi.setText(item.getThoiGianDi());
        holder.txtTuyenDi.setText(item.getTuyenDi());
        if (n == s){
            holder.txtViTri.append(item.getChoNgoi());
        }else {
            holder.txtViTri.append(item.getChoNgoi() + ", ");

        }


        holder.btnGoiDien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + holder.txtSoDienThoaiKH.getText().toString()));
                if (ActivityCompat.checkSelfPermission(CustomerOfGarageActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                startActivity(callIntent);
            }
        });

        holder.btnHuyCho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViTriHienTai.viTriList = new ArrayList<>();
                ViTriHienTai.danhSachThongTinVe = new ArrayList<>();
                ViTriHienTai.soLuong = n;
                int i = 0;
                for (DatVe item : model.getDanhSachThongTinVe()){
                    if (item != null){
                        ViTriHienTai.danhSachThongTinVe.add(item);
                        ViTriHienTai.giaVe = item.getGia();
                        ViTriHienTai.viTriList.add(new ViTri(item.getIdDatVe(), item.getChoNgoi()));
                        Log.i("VITRI", item.getIdDatVe());
                        i++;
                    }
                }

                Dialog dialog = new DialogDelete_YeuCau(CustomerOfGarageActivity.this);
                dialog.setTitle("Chọn chỗ ngồi để xóa");
                dialog.show();

            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView txtTenXe, txtTuyenDi, txtTenKhachHang, txtViTri, txtTongTien, txtThoiGianDi, txtNgayDi, txtSoDienThoaiKH;
        public Button btnHuyCho, btnGoiDien;

        private ItemOnClickListenner listenner;

        public ViewHolder(View itemView) {
            super(itemView);

            txtTenXe = itemView.findViewById(R.id.txtTenXe_SeatChooseCustomer_Manager);
            txtTuyenDi = itemView.findViewById(R.id.txtTuyenDi_SeatChooseCustomer_Manager);
            txtTenKhachHang = itemView.findViewById(R.id.txtTenKhachHang_SeatChooseCustomer_Manager);
            txtViTri = itemView.findViewById(R.id.txtViTri_SeatChooseCustomer_Manager);
            txtTongTien = itemView.findViewById(R.id.txtTongTien_SeatChooseCustomer_Manager);
            txtThoiGianDi = itemView.findViewById(R.id.txtThoiGianDi_SeatChooseCustomer_Manager);
            txtNgayDi = itemView.findViewById(R.id.txtNgayDi_SeatChooseCustomer_Manager);
            txtSoDienThoaiKH = itemView.findViewById(R.id.txtSoDienThoaiKhachHang_SeatChooseCustomer_Manager);
            btnHuyCho = itemView.findViewById(R.id.btnHuyCho_SeatChooseCustomer_Manager);
            btnGoiDien = itemView.findViewById(R.id.btnGoiDien_SeatChooseCustomer_Manager);

            btnHuyCho.setOnClickListener(this);
            btnGoiDien.setOnClickListener(this);
        }

        public ViewHolder setListenner(ItemOnClickListenner listenner) {
            this.listenner = listenner;
            return this;
        }

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btnGoiDien_SeatChooseCustomer_Manager:
                    listenner.onClick(v, getAdapterPosition(), false);
                    break;
                case R.id.btnHuyCho_SeatChooseCustomer_Manager:
                    listenner.onClick(v, getAdapterPosition(), false);
                    break;
            }
        }
    }


}
*/
