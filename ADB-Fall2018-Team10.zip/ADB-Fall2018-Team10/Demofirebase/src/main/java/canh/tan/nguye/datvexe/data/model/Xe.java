package canh.tan.nguye.datvexe.data.model;

import java.io.Serializable;
import java.util.List;

public class Xe implements Serializable{
    private String bsoXe;
    private String giaTien;
    private String idHX;
    private String imgHinh;
    private String loaiChoNgoi;
    private String loaiXe;
    private String noiDen;
    private String noiDi;
    private String soDienThoai;
    private String tenXe;
    private String thoiGianBDDi;
    private String trangThai;
    private List<ViTri> tang1;
    private List<ViTri> tang2;

    public Xe() {
    }

    public Xe(Builder builder) {
        this.bsoXe = builder.bsoXe;
        this.giaTien = builder.giaTien;
        this.idHX = builder.idHX;
        this.imgHinh = builder.imgHinh;
        this.loaiChoNgoi = builder.loaiChoNgoi;
        this.loaiXe = builder.loaiXe;
        this.noiDen = builder.noiDen;
        this.noiDi = builder.noiDi;
        this.soDienThoai = builder.soDienThoai;
        this.tenXe = builder.tenXe;
        this.thoiGianBDDi = builder.thoiGianBDDi;
        this.trangThai = builder.trangThai;
        this.tang1 = builder.tang1;
        this.tang2 = builder.tang2;
    }

    public String getBSoXe() {
        return bsoXe;
    }

    public String getGiaTien() {
        return giaTien;
    }

    public String getIdHX() {
        return idHX;
    }

    public String getImgHinh() {
        return imgHinh;
    }

    public String getLoaiChoNgoi() {
        return loaiChoNgoi;
    }

    public String getLoaiXe() {
        return loaiXe;
    }

    public String getNoiDen() {
        return noiDen;
    }

    public String getNoiDi() {
        return noiDi;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public String getTenXe() {
        return tenXe;
    }

    public String getThoiGianBDDi() {
        return thoiGianBDDi;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public List<ViTri> getTang1() {
        return tang1;
    }

    public List<ViTri> getTang2() {
        return tang2;
    }

    public static class Builder{
        private String bsoXe;
        private String giaTien;
        private String idHX;
        private String imgHinh;
        private String loaiChoNgoi;
        private String loaiXe;
        private String noiDen;
        private String noiDi;
        private String soDienThoai;
        private String tenXe;
        private String thoiGianBDDi;
        private String trangThai;
        private List<ViTri> tang1;
        private List<ViTri> tang2;

        public Builder() {
        }

        public Builder setBSoXe(String BSoXe) {
            this.bsoXe = BSoXe;
            return this;
        }

        public Builder setGiaTien(String giaTien) {
            this.giaTien = giaTien;
            return this;
        }

        public Builder setIdHX(String idHX) {
            this.idHX = idHX;
            return this;
        }

        public Builder setImgHinh(String imgHinh) {
            this.imgHinh = imgHinh;
            return this;
        }

        public Builder setLoaiChoNgoi(String loaiChoNgoi) {
            this.loaiChoNgoi = loaiChoNgoi;
            return this;
        }

        public Builder setLoaiXe(String loaiXe) {
            this.loaiXe = loaiXe;
            return this;
        }

        public Builder setNoiDen(String noiDen) {
            this.noiDen = noiDen;
            return this;
        }

        public Builder setNoiDi(String noiDi) {
            this.noiDi = noiDi;
            return this;
        }

        public Builder setSoDienThoai(String soDienThoai) {
            this.soDienThoai = soDienThoai;
            return this;
        }

        public Builder setTenXe(String tenXe) {
            this.tenXe = tenXe;
            return this;
        }

        public Builder setThoiGianBDDi(String thoiGianBDDi) {
            this.thoiGianBDDi = thoiGianBDDi;
            return this;
        }

        public Builder setTrangThai(String trangThai) {
            this.trangThai = trangThai;
            return this;
        }

        public Builder setTang1(List<ViTri> tang1) {
            this.tang1 = tang1;
            return this;
        }

        public Builder setTang2(List<ViTri> tang2) {
            this.tang2 = tang2;
            return this;
        }

        public Xe builder(){
            return new Xe(this);
        }
    }
}
