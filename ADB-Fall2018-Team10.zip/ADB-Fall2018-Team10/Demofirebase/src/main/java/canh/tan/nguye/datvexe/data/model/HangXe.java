package canh.tan.nguye.datvexe.data.model;

import java.io.Serializable;

public class HangXe implements Serializable{
    private String diaChi;
    private String soDienThoai;
    private String ngayLap;
    private String imgHinh;
    private String noiDung;
    private String tenHangXe;
    private String suKien;

    public HangXe() {
    }

    public HangXe(Builder builder) {
        this.diaChi = builder.diaChi;
        this.soDienThoai = builder.soDienThoai;
        this.ngayLap = builder.ngayLap;
        this.imgHinh=builder.imgHinh;
        this.noiDung = builder.noiDung;
        this.tenHangXe = builder.tenHangXe;
        this.suKien = builder.suKien;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public String getNgayLap() {
        return ngayLap;
    }

    public String getImgHinh() {
        return imgHinh;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public String getTenHangXe() {
        return tenHangXe;
    }

    public String getSuKien() {
        return suKien;
    }

    public static class Builder{
        private String diaChi;
        private String soDienThoai;
        private String ngayLap;
        private String imgHinh;
        private String noiDung;
        private String tenHangXe;
        private String suKien;

        public Builder() {
        }

        public Builder(String diaChi, String soDienThoai, String ngayLap, String imgHinh, String noiDung, String tenHangXe, String suKien) {
            this.diaChi = diaChi;
            this.soDienThoai = soDienThoai;
            this.ngayLap = ngayLap;
            this.imgHinh = imgHinh;
            this.noiDung = noiDung;
            this.tenHangXe = tenHangXe;
            this.suKien = suKien;
        }

        public Builder setDiaChi(String diaChi) {
            this.diaChi = diaChi;
            return this;
        }

        public Builder setSoDienThoai(String soDienThoai) {
            this.soDienThoai = soDienThoai;
            return this;
        }

        public Builder setNgayLap(String ngayLap) {
            this.ngayLap = ngayLap;
            return this;
        }

        public Builder setImgHinh(String imgHinh) {
            this.imgHinh = imgHinh;
            return this;
        }

        public Builder setNoiDung(String noiDung) {
            this.noiDung = noiDung;
            return this;
        }

        public Builder setTenHangXe(String tenHangXe) {
            this.tenHangXe = tenHangXe;
            return this;
        }

        public Builder setSuKien(String suKien) {
            this.suKien = suKien;
            return this;
        }

        public HangXe builder(){
            return new HangXe(this);
        }
    }
}
