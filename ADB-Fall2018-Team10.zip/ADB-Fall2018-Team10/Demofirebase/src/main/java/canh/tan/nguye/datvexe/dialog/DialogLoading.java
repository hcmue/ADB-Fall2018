package canh.tan.nguye.datvexe.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;

import canh.tan.nguye.datvexe.R;

public class DialogLoading extends Dialog{


    public DialogLoading(@NonNull Context context) {
        super(context);
        requestWindowFeature(1);

        setContentView(R.layout.dialog_loading);
        setCancelable(false);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }
}
