package canh.tan.nguye.datvexe.data;

import java.util.ArrayList;
import java.util.List;

import canh.tan.nguye.datvexe.data.model.DatVe;
import canh.tan.nguye.datvexe.data.model.ViTri;
import canh.tan.nguye.datvexe.data.model.YeuCau;

public class ViTriHienTai {
    public static List<String> viTriList = null;
    public static List<String> viTriListChon = null;
    public static String key_ref;

    public static YeuCau yeuCau = new YeuCau();
}
