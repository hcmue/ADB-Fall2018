package canh.tan.nguye.datvexe.admin.register;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.login.LoginActivity;
import canh.tan.nguye.datvexe.data.model.User;
import canh.tan.nguye.datvexe.dialog.DialogLoading;
import canh.tan.nguye.datvexe.utils.data.DefaultTableFirebase;

public class RegisterActivity extends AppCompatActivity {

    Toolbar toolbar;
    DialogLoading dialogLoading;

    TextInputEditText editEmail, editPassword, editConfirmPassword;
    Button btnRegister;

    FirebaseDatabase database;
    DatabaseReference referenceUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        database = FirebaseDatabase.getInstance();
        referenceUsers = database.getReference(DefaultTableFirebase.USERS);

        addControls();
        addEvents();
    }

    private void addEvents() {
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                Bundle bundle = ActivityOptions.makeCustomAnimation(RegisterActivity.this, R.anim.anim_right_left_1, R.anim.anim_right_left_2).toBundle();
                startActivity(intent, bundle);
                finish();
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(editEmail.getText()) || TextUtils.isEmpty(editPassword.getText()) || TextUtils.isEmpty(editConfirmPassword.getText())){
                    if (TextUtils.isEmpty(editEmail.getText())){
                        editEmail.setError(getString(R.string.txt_set_error_email));
                    }
                    if (TextUtils.isEmpty(editPassword.getText())){
                        editPassword.setError(getString(R.string.txt_set_error_password));
                    }
                    if (TextUtils.isEmpty(editConfirmPassword.getText())){
                        editConfirmPassword.setError(getString(R.string.txt_set_error_password));
                    }

                }else {
                    if (!editPassword.getText().toString().equals(editConfirmPassword.getText().toString())){
                        Toast.makeText(RegisterActivity.this, R.string.txt_check_password, Toast.LENGTH_SHORT).show();
                    }else {
                        dialogLoading.show();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {

                                User user = new User.Builder()
                                        .setAddress("")
                                        .setPassword(editPassword.getText().toString())
                                        .builder();

                                referenceUsers.child(editEmail.getText().toString()).setValue(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Toast.makeText(RegisterActivity.this, R.string.txt_create_account_success, Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                                        Bundle bundle = ActivityOptions.makeCustomAnimation(RegisterActivity.this, R.anim.anim_right_left_1, R.anim.anim_right_left_2).toBundle();
                                        startActivity(intent, bundle);
                                        finish();
                                        dialogLoading.dismiss();
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(RegisterActivity.this, getString(R.string.txt_check_account_exists), Toast.LENGTH_SHORT).show();
                                        dialogLoading.dismiss();
                                    }
                                });
                            }
                        }, 2000);
                    }
                }
            }
        });
    }

    private void addControls() {
        dialogLoading = new DialogLoading(RegisterActivity.this);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        editEmail = findViewById(R.id.editEmail_Register);
        editPassword = findViewById(R.id.editPassword_Register);
        editConfirmPassword = findViewById(R.id.editConfirmPassword_Register);
        btnRegister = findViewById(R.id.btnRegister_Register);
    }
}
