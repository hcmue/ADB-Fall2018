package canh.tan.nguye.datvexe.admin.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.fragment.CarManagerFragment;
import canh.tan.nguye.datvexe.admin.fragment.CustomerManagerFragment;
import canh.tan.nguye.datvexe.admin.fragment.SettingManagerFragment;
import canh.tan.nguye.datvexe.admin.fragment.StatisticsManagerFragment;
import canh.tan.nguye.datvexe.utils.data.DefaultCommon;

public class PagerAdapter extends FragmentStatePagerAdapter {
    Context context;
    CustomerManagerFragment customerManagerFragment;
    CarManagerFragment carManagerFragment;
    StatisticsManagerFragment statisticsManagerFragment;
    SettingManagerFragment settingManagerFragment;

    public PagerAdapter(FragmentManager fm, Context context) {
        super(fm);
        this.context = context;
    }

    @Override
    public Fragment getItem(int position) {
        if (position == 0){
            customerManagerFragment = new CustomerManagerFragment();
            return customerManagerFragment;
        }

        if (position == 1){
            carManagerFragment = new CarManagerFragment();
            return carManagerFragment;
        }

        if (position == 2){
            statisticsManagerFragment = new StatisticsManagerFragment();
            return statisticsManagerFragment;
        }

        settingManagerFragment = new SettingManagerFragment();
        return settingManagerFragment;
    }

    @Override
    public int getCount() {
        return 4;
    }

    public View getTabView(int position){
        View view;

        view = LayoutInflater.from(context).inflate(R.layout.item_tab_layout, null, false);

        ImageView img = view.findViewById(R.id.imgTitle_TabLayout);
        TextView txt = view.findViewById(R.id.txtTitle_TabLayout);

        img.setImageResource(DefaultCommon.imageTab[position]);
        txt.setText(DefaultCommon.titleTab[position]);

        return view;
    }
}
