package canh.tan.nguye.datvexe.data;

import java.util.List;

public class GetHangXeHienTai {
    public static String idHangXe;
    public static String idXe;
    public static List<String> choNgoi;
}
