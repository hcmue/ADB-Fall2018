package canh.tan.nguye.datvexe.view.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.data.model.YeuCau;

public class ChooseSeatPaymentActivity extends AppCompatActivity {

    RadioButton rdbHangXe, rdbNganHang;
    EditText editTenNganHang, editTenTaiKhoan, editSoTaiKhoan;
    LinearLayout layout;
    Button btnTiepTuc;

    YeuCau yeuCau;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_seat_payment);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        yeuCau = (YeuCau) getIntent().getSerializableExtra("DATA");
        addControls();
        addEvents();
    }

    private void addEvents() {
        rdbHangXe.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    layout.setVisibility(View.GONE);
                }
            }
        });

        rdbNganHang.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    layout.setVisibility(View.VISIBLE);
                }
            }
        });

        btnTiepTuc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseSeatPaymentActivity.this, ConfirmDatVeActivity.class);
                intent.putExtra("DATA", yeuCau);
                startActivity(intent);
                finish();
            }
        });


    }

    private void addControls() {
        rdbHangXe = findViewById(R.id.rdbNopQuaHangXe_ChooseSeatPayment);
        rdbNganHang = findViewById(R.id.rdbNopQuaNganHang_ChooseSeatPayment);
        editTenNganHang = findViewById(R.id.editTenNganHang_ChooseSeatPayment);
        editTenTaiKhoan = findViewById(R.id.editTenTaiKhoan_ChooseSeatPayment);
        editSoTaiKhoan = findViewById(R.id.editSoTaiKhoan_ChooseSeatPayment);
        layout = findViewById(R.id.llayout_info_bank);
        btnTiepTuc = findViewById(R.id.btnTiepTuc_ChooseSeatPayment);
        layout.setVisibility(View.GONE);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}
