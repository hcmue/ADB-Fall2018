package canh.tan.nguye.datvexe.view.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.data.model.DatVe;
import canh.tan.nguye.datvexe.data.model.YeuCau;

public class ConfirmInfoCustomerActivity extends AppCompatActivity implements View.OnClickListener {

    TextView txtTenHangXe, txtTenXe, txtTuyenDi, txtGioDi, txtNgayDi, txtSoGhe, txtViTri, txtTongTien;
    EditText editTenNguoiNhan, editSoDienThoai, editEmail;
    Button btnTiepTuc;

    YeuCau yeuCau;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_info_customer);

        addControls();
        initDatas();
        addEvents();
    }

    @SuppressLint("SetTextI18n")
    private void initDatas() {
        Locale locale = new Locale("en", "US");
        NumberFormat numberFormat = NumberFormat.getNumberInstance(locale);

        txtTenHangXe.setText(yeuCau.getTenHangXe());
        txtTenXe.setText(yeuCau.getThongTinDatVe().getTenXe());
        txtTuyenDi.setText(yeuCau.getThongTinDatVe().getTuyenDi());
        txtGioDi.setText(yeuCau.getThongTinDatVe().getThoiGianDi());
        txtNgayDi.setText(yeuCau.getThongTinDatVe().getNgayDat());
        txtSoGhe.setText(yeuCau.getSoLuong());
        txtViTri.setText("");
        txtViTri.append(yeuCau.getThongTinDatVe().getChoNgoi());

        txtTongTien.setText(numberFormat.format(Integer.parseInt(yeuCau.getTongTien())) + " VNĐ");
    }

    private void addEvents() {
        btnTiepTuc.setOnClickListener(this);
    }

    private void addControls() {
        if (yeuCau == null){
            yeuCau = (YeuCau) getIntent().getSerializableExtra("DAT_VE_LIST");
        }

        txtTenHangXe = findViewById(R.id.txtTenHangXe_ConfirmInfoCustomer);
        txtTenXe = findViewById(R.id.txtTenXe_ConfirmInfoCustomer);
        txtTuyenDi = findViewById(R.id.txtTuyen_ConfirmInfoCustomer);
        txtGioDi = findViewById(R.id.txtGioDi_ConfirmInfoCustomer);
        txtNgayDi = findViewById(R.id.txtNgayDi_ConfirmInfoCustomer);
        txtSoGhe = findViewById(R.id.txtSoGheDaDat_ConfirmInfoCustomer);
        txtViTri = findViewById(R.id.txtViTri_ConfirmInfoCustomer);
        txtTongTien = findViewById(R.id.txtTongTien_ConfirmInfoCustomer);
        editTenNguoiNhan = findViewById(R.id.editTenNguoiNhan_ConfirmInfoCustomer);
        editSoDienThoai = findViewById(R.id.editSoDienThoai_ConfirmInfoCustomer);
        editEmail = findViewById(R.id.editEmail_ConfirmInfoCustomer);
        btnTiepTuc = findViewById(R.id.btnTiepTuc_ConfirmInfoCustomer);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnTiepTuc_ConfirmInfoCustomer:
                String ten = editTenNguoiNhan.getText().toString();
                String sdt = editSoDienThoai.getText().toString();
                String email = editEmail.getText().toString();

                if (ten.isEmpty() || sdt.isEmpty()){
                    if (ten.isEmpty()){
                        editTenNguoiNhan.setError("Bạn chưa nhập tên");
                    }
                    if (sdt.isEmpty()){
                        editSoDienThoai.setError("Bạn chưa nhập số điện thoại");
                    }
                }else {
                    YeuCau data = new YeuCau.Builder()
                            .setIdhangXe(yeuCau.getIdhangXe())
                            .setTenHangXe(yeuCau.getTenHangXe())
                            .setThongTinDatVe(yeuCau.getThongTinDatVe())
                            .setEmail(email)
                            .setSoDienThoai(sdt)
                            .setSoLuong(yeuCau.getSoLuong())
                            .setTenNguoiNhan(ten)
                            .setTongTien(yeuCau.getTongTien())
                            .builder();

                    Intent intent = new Intent(ConfirmInfoCustomerActivity.this, ChooseSeatPaymentActivity.class);
                    intent.putExtra("DATA", data);
                    startActivity(intent);
                    finish();
                }
        }
    }
}
