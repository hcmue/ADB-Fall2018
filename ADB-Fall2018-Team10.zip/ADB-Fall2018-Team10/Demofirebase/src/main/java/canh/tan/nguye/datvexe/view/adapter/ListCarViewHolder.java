package canh.tan.nguye.datvexe.view.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import canh.tan.nguye.datvexe.R;

public class ListCarViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public ImageView img, imgIsNotification;
    public TextView txtCarBrand, txtDirection, txtTimeStartCar, txtNameCar, txtFareCar, txtClassifyCar, txtClassifySeat;
    private ItemOnClickListenner listenner;

    public ListCarViewHolder(View itemView) {
        super(itemView);

        img = itemView.findViewById(R.id.imgCar_ListCar);
        txtCarBrand = itemView.findViewById(R.id.txtCarBrandName_ListCar);
        txtDirection = itemView.findViewById(R.id.txtDirection_ListCar);
        txtTimeStartCar = itemView.findViewById(R.id.txtTimeStartCar_ListCar);
        txtNameCar = itemView.findViewById(R.id.txtNameCar_ListCar);
        txtFareCar = itemView.findViewById(R.id.txtFareCar_ListCar);
        txtClassifyCar = itemView.findViewById(R.id.txtClassifyCar_ListCar);
        txtClassifySeat = itemView.findViewById(R.id.txtClassifySeat_ListCar);
        imgIsNotification = itemView.findViewById(R.id.img_is_notification);
        itemView.setOnClickListener(this);
    }

    public ListCarViewHolder setListenner(ItemOnClickListenner listenner) {
        this.listenner = listenner;
        return this;
    }

    @Override
    public void onClick(View v) {
        listenner.onClick(v, getAdapterPosition(), false);
    }
}
