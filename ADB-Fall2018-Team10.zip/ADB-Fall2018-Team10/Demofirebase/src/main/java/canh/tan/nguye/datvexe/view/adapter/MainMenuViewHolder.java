package canh.tan.nguye.datvexe.view.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import canh.tan.nguye.datvexe.R;

public class MainMenuViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public ImageView img;
    public TextView txtTenHang, txtDiaChi, txtNoiDung;

    private ItemOnClickListenner listenner;

    public MainMenuViewHolder(View itemView) {
        super(itemView);
        img = itemView.findViewById(R.id.imgHinh_MainMenu);
        txtTenHang = itemView.findViewById(R.id.txtTenHangXe_MainMenu);
        txtDiaChi = itemView.findViewById(R.id.txtDiaChi_MainMenu);
        txtNoiDung = itemView.findViewById(R.id.txtNoiDung_MainMenu);

        itemView.setOnClickListener(this);
    }

    public MainMenuViewHolder setListenner(ItemOnClickListenner listenner) {
        this.listenner = listenner;
        return this;
    }

    @Override
    public void onClick(View v) {
        listenner.onClick(v, getAdapterPosition(), false);
    }

    /*public ImageView img, imgIsNotification;
    public TextView txtCarBrand, txtDirection, txtTimeStartCar, txtNameCar, txtFareCar, txtClassifyCar, txtClassifySeat;
    private ItemOnClickListenner listenner;

    public MainMenuViewHolder(View itemView) {
        super(itemView);
        img = itemView.findViewById(R.id.imgCar_MainMenu);
        txtCarBrand = itemView.findViewById(R.id.txtCarBrandName_MainMenu);
        txtDirection = itemView.findViewById(R.id.txtDirection_MainMenu);
        txtTimeStartCar = itemView.findViewById(R.id.txtTimeStartCar_MainMenu);
        txtNameCar = itemView.findViewById(R.id.txtNameCar_MainMenu);
        txtFareCar = itemView.findViewById(R.id.txtFareCar_MainMenu);
        txtClassifyCar = itemView.findViewById(R.id.txtClassifyCar_MainMenu);
        txtClassifySeat = itemView.findViewById(R.id.txtClassifySeat_MainMenu);
        imgIsNotification = itemView.findViewById(R.id.img_is_notification);
        itemView.setOnClickListener(this);
    }

    public MainMenuViewHolder setListenner(ItemOnClickListenner listenner) {
        this.listenner = listenner;
        return this;
    }

    @Override
    public void onClick(View v) {
        listenner.onClick(v, getAdapterPosition(), false);
    }*/
}
