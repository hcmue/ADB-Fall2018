package canh.tan.nguye.datvexe.data.model;

import java.io.Serializable;

public class ViTri implements Serializable{
    private String idVItri;
    private String tenViTri;

    public ViTri() {
    }

    public ViTri(String idVItri, String tenViTri) {
        this.idVItri = idVItri;
        this.tenViTri = tenViTri;
    }

    public String getIdVItri() {
        return idVItri;
    }

    public ViTri setIdVItri(String idVItri) {
        this.idVItri = idVItri;
        return this;
    }

    public String getTenViTri() {
        return tenViTri;
    }

    public ViTri setTenViTri(String tenViTri) {
        this.tenViTri = tenViTri;
        return this;
    }
}
