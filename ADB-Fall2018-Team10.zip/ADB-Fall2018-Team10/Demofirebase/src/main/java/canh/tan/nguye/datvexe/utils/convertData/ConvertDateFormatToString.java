package canh.tan.nguye.datvexe.utils.convertData;

import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ConvertDateFormatToString {
    public static String convertDateToString(){
        Date today = new Date(System.currentTimeMillis());
        SimpleDateFormat timeFormat = new SimpleDateFormat("dd/MM/yyyy");
        return timeFormat.format(today.getTime());
    }

    public static String processFormat(String date) {
        String a[] = date.split("/");
        date = Integer.parseInt(a[0].toString()) + "/" + Integer.parseInt(a[1].toString()) + "/" + a[2].toString();
        return date;
    }

}
