package canh.tan.nguye.datvexe.view.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Map;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.data.model.DatVe;
import canh.tan.nguye.datvexe.data.model.YeuCau;

public class ConfirmDatVeActivity extends AppCompatActivity {

    TextView txtTenHangXe, txtTenXe, txtTuyenDi, txtThoiGianDi, txtNgayDi, txtSoLuong, txtViTri, txtTongTien,
                txtTenNganHang, txtTenTaiKhoan, txtSoTaiKhoan, txtTenNguoiNhan, txtSoDienThoai, txtEmail;

    RadioButton rdbSDT, rdbEmail;
    Button btnHoanThanh;

    YeuCau yeuCau;

    FirebaseDatabase database;
    DatabaseReference referenceRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_dat_ve);

        database = FirebaseDatabase.getInstance();
        referenceRequest = database.getReference("YeuCau");

        yeuCau = (YeuCau) getIntent().getSerializableExtra("DATA");

        addControls();
        initDatas();
        addEvents();
    }

    @SuppressLint("SetTextI18n")
    private void initDatas() {
        Locale locale = new Locale("en", "US");
        NumberFormat numberFormat = NumberFormat.getNumberInstance(locale);

        txtTenHangXe.setText(yeuCau.getTenHangXe());
        txtTenXe.setText(yeuCau.getThongTinDatVe().getTenXe());
        txtTuyenDi.setText(yeuCau.getThongTinDatVe().getTuyenDi());
        txtThoiGianDi.setText(yeuCau.getThongTinDatVe().getThoiGianDi());
        txtNgayDi.setText(yeuCau.getThongTinDatVe().getNgayDat());
        txtSoLuong.setText(yeuCau.getSoLuong());
        txtViTri.setText("");
        txtViTri.append(yeuCau.getThongTinDatVe().getChoNgoi());

        txtTongTien.setText(numberFormat.format(Integer.parseInt(yeuCau.getTongTien())) + " VNĐ");
        txtTenNguoiNhan.setText(yeuCau.getTenNguoiNhan());
        txtSoDienThoai.setText(yeuCau.getSoDienThoai());
        txtEmail.setText(yeuCau.getEmail());

    }

    private void addEvents() {
        btnHoanThanh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                YeuCau item = new YeuCau.Builder()
                        .setEmail(yeuCau.getEmail())
                        .setIdhangXe(yeuCau.getIdhangXe())
                        .setSoDienThoai(yeuCau.getSoDienThoai())
                        .setSoLuong(yeuCau.getSoLuong())
                        .setTenHangXe(yeuCau.getTenHangXe())
                        .setTenNguoiNhan(yeuCau.getTenNguoiNhan())
                        .setThongTinDatVe(yeuCau.getThongTinDatVe())
                        .setTongTien(yeuCau.getTongTien())
                        .setTrangThai("Chưa xác nhận")
                        .builder();
                referenceRequest.child(String.valueOf(System.currentTimeMillis())).setValue(item);
                Toast.makeText(ConfirmDatVeActivity.this, "Đặt vé thành công", Toast.LENGTH_SHORT).show();


                sendSMS(txtSoDienThoai.getText().toString(), "Bạn đã đặt vé thành công tại app 'Đặt Vé Xe' của chúng tôi với các thông tin sau: " +
                        "\n" + txtTenHangXe.getText().toString() +
                        "\n" + txtTenXe.getText().toString() +
                        "\n" + txtTuyenDi.getText().toString() +
                        "\n" + txtNgayDi.getText().toString() +
                        "\n" + txtThoiGianDi.getText().toString() +
                        "\n" + txtSoLuong.getText().toString() +
                        "\n" + txtViTri.getText().toString() +
                        "\n" + txtTenHangXe.getText().toString() +
                        "\n" + txtSoDienThoai.getText().toString());
                finish();
            }
        });
    }

    private void sendSMS(String phoneNumber, String mes){
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, mes, null, null);
    }


    private void addControls() {
        txtTenHangXe = findViewById(R.id.txtTenHangXe_ConfirmDatVe);
        txtTenXe = findViewById(R.id.txtTenXe_ConfirmDatVe);
        txtTuyenDi = findViewById(R.id.txtTuyenDi_ConfirmDatVe);
        txtThoiGianDi = findViewById(R.id.txtThoiGianDi_ConfirmDatVe);
        txtNgayDi = findViewById(R.id.txtNgayDi_ConfirmDatVe);
        txtSoLuong = findViewById(R.id.txtSoLuong_ConfirmDatVe);
        txtViTri = findViewById(R.id.txtViTri_ConfirmDatVe);
        txtTongTien = findViewById(R.id.txtTongTien_ConfirmDatVe);
        /*txtTenNganHang = findViewById(R.id.txtTenNganHang_ConfirmDatVe);
        txtTenTaiKhoan = findViewById(R.id.txtTenTaiKhoan_ConfirmDatVe);
        txtSoTaiKhoan = findViewById(R.id.txtSoTaiKhoan_ConfirmDatVe);*/
        txtTenNguoiNhan = findViewById(R.id.txtTenNguoiNhan_ConfirmDatVe);
        txtSoDienThoai = findViewById(R.id.txtSoDienThoai_ConfirmDatVe);
        txtEmail = findViewById(R.id.txtEmail_ConfirmDatVe);

        rdbEmail = findViewById(R.id.rdbXacNhanQuaEmail_ConfirmDatVe);
        rdbSDT = findViewById(R.id.rdbXacNhanQuaDT_ConfirmDatVe);
        btnHoanThanh = findViewById(R.id.btnHoanThanh_ConfirmDatVe);
    }
}
