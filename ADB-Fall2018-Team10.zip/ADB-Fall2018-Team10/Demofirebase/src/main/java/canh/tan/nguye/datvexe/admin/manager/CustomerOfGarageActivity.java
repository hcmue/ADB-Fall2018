package canh.tan.nguye.datvexe.admin.manager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.arch.lifecycle.Lifecycle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.adapter.CustomerManagerViewHolder;
import canh.tan.nguye.datvexe.admin.adapter.ItemOnClickListenner;
import canh.tan.nguye.datvexe.data.ViTriHienTai;
import canh.tan.nguye.datvexe.data.model.DatVe;
import canh.tan.nguye.datvexe.data.model.ViTri;
import canh.tan.nguye.datvexe.data.model.YeuCau;
import canh.tan.nguye.datvexe.dialog.DialogDelete_YeuCau;

public class CustomerOfGarageActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;

    ProgressBar progress;

    FirebaseDatabase database;
    DatabaseReference referenceYeuCau;
    FirebaseRecyclerOptions<YeuCau> options;
    FirebaseRecyclerAdapter<YeuCau, CustomerManagerViewHolder> adapter;


    String idHangXe;
    int n;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_of_garage);

        database = FirebaseDatabase.getInstance();
        referenceYeuCau = database.getReference("/YeuCau");
        idHangXe = getIntent().getStringExtra("HangXeID");
        progress = findViewById(R.id.progress);
        progress.setVisibility(View.GONE);

        addControls();
        addEvents();
    }

    private void addEvents() {

        Log.i("THONGTIN", idHangXe);
        Query query = database.getReference().child("YeuCau").orderByChild("idhangXe").equalTo(idHangXe);
        options = new FirebaseRecyclerOptions.Builder<YeuCau>()
                .setQuery(query,YeuCau.class)
                .build();


        adapter = new FirebaseRecyclerAdapter<YeuCau, CustomerManagerViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final CustomerManagerViewHolder holder,final int position, @NonNull final YeuCau model) {

                holder.txtViTri.setText(model.getThongTinDatVe().getChoNgoi());
                holder.txtSoDienThoaiKH.setText(model.getSoDienThoai());
                holder.txtTenKhachHang.setText(model.getTenNguoiNhan());
                holder.txtTongTien.setText(model.getTongTien());
                holder.txtTenXe.setText(model.getThongTinDatVe().getTenXe());
                holder.txtNgayDi.setText(model.getThongTinDatVe().getNgayDat());

                holder.txtThoiGianDi.setText(model.getThongTinDatVe().getThoiGianDi());
                holder.txtTuyenDi.setText(model.getThongTinDatVe().getTuyenDi());
                holder.txtTrangThai_SeatChooseCustomer_Manager.setText(model.getTrangThai());


                holder.setListenner(new ItemOnClickListenner() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        ViTriHienTai.key_ref = adapter.getRef(position).getKey();
                        ViTriHienTai.yeuCau = new YeuCau();
                        ViTriHienTai.yeuCau = model;
                        Log.i("KEY_REF", ViTriHienTai.key_ref + " - " + adapter.getRef(position).getKey());
                        ViTriHienTai.viTriList = new ArrayList<>();
                        String[] strings = model.getThongTinDatVe().getChoNgoi().split(",");
                        ViTriHienTai.viTriList.addAll(Arrays.asList(strings));
                        Dialog dialog = new DialogDelete_YeuCau(CustomerOfGarageActivity.this);
                        dialog.setTitle("Chọn chỗ ngồi để xóa");
                        dialog.show();
                    }
                });

                holder.btnGoiDien.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent callIntent = new Intent(Intent.ACTION_CALL);
                        callIntent.setData(Uri.parse("tel:" + holder.txtSoDienThoaiKH.getText().toString()));
                        if (ActivityCompat.checkSelfPermission(CustomerOfGarageActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            // TODO: Consider calling
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }
                        startActivity(callIntent);
                    }
                });

                if (model.getTrangThai().equals("Chưa xác nhận")){
                    holder.btnXacNhan.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            progress.setVisibility(View.VISIBLE);

                            new Handler().postDelayed(new Runnable() {
                               @Override
                               public void run() {
                                   progress.setVisibility(View.GONE);

                                   YeuCau item = new YeuCau.Builder()
                                           .setThongTinDatVe(model.getThongTinDatVe())
                                           .setIdhangXe(model.getIdhangXe())
                                           .setSoLuong(model.getSoLuong())
                                           .setTenHangXe(model.getTenHangXe())
                                           .setTongTien(model.getTongTien())
                                           .setEmail(model.getEmail())
                                           .setSoDienThoai(model.getSoDienThoai())
                                           .setTenNguoiNhan(model.getTenNguoiNhan())
                                           .setTrangThai("Xác nhận")
                                           .builder();

                                   database.getReference("YeuCau").child(adapter.getRef(position).getKey()+"").setValue(item);
                               }
                           },1500);
                        }

                    });
                }else {
                    holder.btnXacNhan.setVisibility(View.INVISIBLE);
                }


            }

            @NonNull
            @Override
            public CustomerManagerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new CustomerManagerViewHolder(LayoutInflater.from(CustomerOfGarageActivity.this).inflate(R.layout.item_customer_manager, parent, false));
            }
        };
        recyclerView.setAdapter(adapter);

    }

    private void addControls() {
        recyclerView = findViewById(R.id.recyclerViewCustomer_G);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);


    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
