package canh.tan.nguye.datvexe.data.model;

import com.google.firebase.database.Exclude;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class YeuCau implements Serializable{
    private String idhangXe;
    private String tenHangXe;
    private String soLuong;
    private String tongTien;
    private String tenNguoiNhan;
    private String soDienThoai;
    private String email;
    private String trangThai;
    private DatVe thongTinDatVe;

    public YeuCau() {
    }

    public YeuCau(Builder builder) {
        this.idhangXe = builder.idhangXe;
        this.tenHangXe = builder.tenHangXe;
        this.soLuong = builder.soLuong;
        this.tongTien = builder.tongTien;
        this.tenNguoiNhan = builder.tenNguoiNhan;
        this.soDienThoai = builder.soDienThoai;
        this.email = builder.email;
        this.trangThai = builder.trangThai;
        this.thongTinDatVe = builder.thongTinDatVe;
    }

    /*@Exclude
    public Map<String, Object> toMap(){
        HashMap<String, Object> result = new HashMap<>();
        result.put("idhangXe", getIdhangXe());
        result.put("tenHangXe", getTenHangXe());
        result.put("soLuong", getSoLuong());
        result.put("tongTien", getTongTien());
        result.put("tenNguoiNhan", getTenNguoiNhan());
        result.put("soDienThoai", getSoDienThoai());
        result.put("email", getEmail());
        result.put("thongTinDatVe", getThongTinDatVe());

        return result;
    }*/

    public String getIdhangXe() {
        return idhangXe;
    }

    public String getTenHangXe() {
        return tenHangXe;
    }

    public String getSoLuong() {
        return soLuong;
    }

    public String getTongTien() {
        return tongTien;
    }

    public String getTenNguoiNhan() {
        return tenNguoiNhan;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public String getEmail() {
        return email;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public DatVe getThongTinDatVe() {
        return thongTinDatVe;
    }

    public static class Builder{
        private String idhangXe;
        private String tenHangXe;
        private String soLuong;
        private String tongTien;
        private String tenNguoiNhan;
        private String soDienThoai;
        private String email;
        private String trangThai;
        private DatVe thongTinDatVe;

        public Builder() {
        }

        public Builder(String idhangXe, String tenHangXe, String soLuong, String tongTien, String tenNguoiNhan, String soDienThoai, String email, String trangThai, DatVe thongTinDatVe) {
            this.idhangXe = idhangXe;
            this.tenHangXe = tenHangXe;
            this.soLuong = soLuong;
            this.tongTien = tongTien;
            this.tenNguoiNhan = tenNguoiNhan;
            this.soDienThoai = soDienThoai;
            this.email = email;
            this.trangThai = trangThai;
            this.thongTinDatVe = thongTinDatVe;
        }

        public Builder setIdhangXe(String idhangXe) {
            this.idhangXe = idhangXe;
            return this;
        }

        public Builder setTenHangXe(String tenHangXe) {
            this.tenHangXe = tenHangXe;
            return this;
        }

        public Builder setSoLuong(String soLuong) {
            this.soLuong = soLuong;
            return this;
        }

        public Builder setTongTien(String tongTien) {
            this.tongTien = tongTien;
            return this;
        }

        public Builder setTenNguoiNhan(String tenNguoiNhan) {
            this.tenNguoiNhan = tenNguoiNhan;
            return this;
        }

        public Builder setSoDienThoai(String soDienThoai) {
            this.soDienThoai = soDienThoai;
            return this;
        }

        public Builder setEmail(String email) {
            this.email = email;
            return this;
        }

        public Builder setTrangThai(String trangThai) {
            this.trangThai = trangThai;
            return this;
        }

        public Builder setThongTinDatVe(DatVe thongTinDatVe) {
            this.thongTinDatVe = thongTinDatVe;
            return this;
        }

        public YeuCau builder(){
            return new YeuCau(this);
        }
    }
}
