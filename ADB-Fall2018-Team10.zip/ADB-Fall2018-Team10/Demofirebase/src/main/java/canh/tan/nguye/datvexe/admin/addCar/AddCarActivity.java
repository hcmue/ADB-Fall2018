package canh.tan.nguye.datvexe.admin.addCar;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.adapter.CreateCarAdapter;
import canh.tan.nguye.datvexe.data.GetViTriXe;
import canh.tan.nguye.datvexe.data.model.ViTri;
import canh.tan.nguye.datvexe.data.model.Xe;

public class AddCarActivity extends AppCompatActivity implements View.OnClickListener{

    private static final int PICK_FROM_FILE = 1;
    private static final int PICK_FROM_CAMERA = 2;
    FirebaseDatabase database;
    FirebaseStorage storage;
    StorageReference imgRef;

    ImageView img_car, img_add_car;
    CreateCarAdapter adapter1, adapter2;
    Uri imgUri;

    EditText edt_name_car,
            edt_phone_car,
            edt_position_start_car,
            edt_position_end_car,
            edt_time_start,
            edt_plates_car,
            edt_fare_car;
    TextView txtChoNgoi;
    GridView grv_postion_seat_one, grv_postion_seat_two;
    List<ViTri> listOne, listTwo;


    Button btn_reset_seat_one, btn_reset_seat_two, btn_submit;

    String idHangXe;
    File localFile = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_car);

        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        imgRef = storage.getReference();

        idHangXe = getIntent().getStringExtra("HangXeID");

        addControls();
        addEvents();
    }

    private void addEvents() {
        btn_reset_seat_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initDialogOne();
            }
        });

        btn_reset_seat_two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initDialogTwo();
            }
        });

        img_add_car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(AddCarActivity.this, v);
                popupMenu.inflate(R.menu.menu_popup_select_image);
                popupMenu.show();
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.item_file:
                                Intent intent = new Intent();
                                intent.setType("image/*");
                                intent.setAction(Intent.ACTION_GET_CONTENT);
                                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_FROM_FILE);
                                break;
                            case R.id.item_camera:
                                Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                startActivityForResult(takePicture, PICK_FROM_CAMERA);
                                break;
                        }
                        return true;
                    }
                });
            }
        });
        btn_submit.setOnClickListener(this);
    }

    private void addControls() {
        img_car = findViewById(R.id.img_car);
        img_add_car = findViewById(R.id.img_add_car);
        edt_name_car = findViewById(R.id.edt_name_car);
        edt_phone_car = findViewById(R.id.edt_phone_car);
        edt_position_start_car = findViewById(R.id.edt_position_start_car);
        edt_position_end_car = findViewById(R.id.edt_position_end_car);
        edt_time_start = findViewById(R.id.edt_time_start);
        edt_plates_car = findViewById(R.id.edt_plates_car);
        edt_fare_car = findViewById(R.id.edt_fare_car);
        txtChoNgoi = findViewById(R.id.txtChoNgoi);
        grv_postion_seat_one = findViewById(R.id.grv_postion_seat_one);
        grv_postion_seat_two = findViewById(R.id.grv_postion_seat_two);
        btn_reset_seat_one = findViewById(R.id.btn_reset_seat_one);
        btn_reset_seat_two = findViewById(R.id.btn_reset_seat_two);
        btn_submit = findViewById(R.id.btn_submit);

        listOne = new ArrayList<>();
        listTwo = new ArrayList<>();

        getDataFirebase();

    }

    private void initDialogOne() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_set_amount_seat);
        dialog.setTitle("Chọn sô lượng chỗ ngồi");
        final EditText edit = dialog.findViewById(R.id.editSoLuongDialog);
        Button btnChapNhan = dialog.findViewById(R.id.btnChapNhan);
        Button btnTroLai = dialog.findViewById(R.id.btnTroLai);
        dialog.show();

        btnChapNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Integer.parseInt(String.valueOf(edit.getText())) < 10 || Integer.parseInt(String.valueOf(edit.getText())) >= 25){
                    edit.setError("Số lượng ghế phải >= 10 và < 24");
                }else {
                    for (int i = 0; i < Integer.parseInt(String.valueOf(edit.getText())); i++){
                        listOne.add(new ViTri(i+"", GetViTriXe.getViTri().get(i)));
                    }

                    adapter1 = new CreateCarAdapter(AddCarActivity.this, listOne);
                    grv_postion_seat_one.setAdapter(adapter1);

                    dialog.dismiss();
                }

                if (TextUtils.isEmpty(edit.getText())){
                    edit.setError("Không được bỏ trống!");
                }
            }
        });

        btnTroLai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

    private void initDialogTwo() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_set_amount_seat);
        dialog.setTitle("Chọn sô lượng chỗ ngồi");
        final EditText edit = dialog.findViewById(R.id.editSoLuongDialog);
        Button btnChapNhan = dialog.findViewById(R.id.btnChapNhan);
        Button btnTroLai = dialog.findViewById(R.id.btnTroLai);
        dialog.show();

        btnChapNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Integer.parseInt(String.valueOf(edit.getText())) < 10 || Integer.parseInt(String.valueOf(edit.getText())) >= 25){
                    edit.setError("Số lượng ghế phải >= 10 và < 24");
                }else {
                    int size = 0;
                    if (!listOne.isEmpty()){
                        size = Integer.parseInt(String.valueOf(edit.getText())) + listOne.size();

                        for (int i = listOne.size(); i < size; i++){
                            listTwo.add(new ViTri(i + "", GetViTriXe.getViTri().get(i)));
                        }

                        adapter2 = new CreateCarAdapter(AddCarActivity.this, listTwo);
                        grv_postion_seat_two.setAdapter(adapter2);
                    }else {
                        Toast.makeText(AddCarActivity.this, "Bạn phải khởi tạo tầng 1 trước!", Toast.LENGTH_SHORT).show();
                    }

                    dialog.dismiss();
                }

                if (TextUtils.isEmpty(edit.getText())){
                    edit.setError("Không được bỏ trống!");
                }
            }
        });

        btnTroLai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

    private void getDataFirebase() {

    }

    private void uploadFile(){
        if (TextUtils.isEmpty(edt_name_car.getText().toString()) ||
                TextUtils.isEmpty(edt_fare_car.getText().toString()) ||
                TextUtils.isEmpty(edt_phone_car.getText().toString()) ||
                TextUtils.isEmpty(edt_plates_car.getText().toString()) ||
                TextUtils.isEmpty(edt_position_end_car.getText().toString()) ||
                TextUtils.isEmpty(edt_position_start_car.getText().toString()) ||
                TextUtils.isEmpty(edt_time_start.getText().toString())){
            Toast.makeText(this, "Không được bỏ trống", Toast.LENGTH_SHORT).show();
        }else {
            if (imgUri != null){

                final ProgressDialog progressDialog = new ProgressDialog(AddCarActivity.this);
                progressDialog.setTitle("Uploading...");
                progressDialog.show();

                final StorageReference riversRef = imgRef.child(idHangXe +"/" + String.valueOf(System.currentTimeMillis()) + ".jpg");

                riversRef.putFile(imgUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                riversRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        Xe xe = new Xe.Builder()
                                                .setIdHX(idHangXe)
                                                .setGiaTien(edt_fare_car.getText().toString())
                                                .setBSoXe(edt_plates_car.getText().toString())
                                                .setTenXe(edt_name_car.getText().toString())
                                                .setLoaiXe("2 tầng")
                                                .setImgHinh(uri.toString())
                                                .setLoaiChoNgoi(txtChoNgoi.getText().toString())
                                                .setNoiDen(edt_position_end_car.getText().toString())
                                                .setNoiDi(edt_position_start_car.getText().toString())
                                                .setSoDienThoai(edt_phone_car.getText().toString())
                                                .setThoiGianBDDi(edt_time_start.getText().toString())
                                                .setTrangThai("Còn")
                                                .setTang1(listOne)
                                                .setTang2(listTwo)
                                                .builder();

                                        database.getReference("Xe").push().setValue(xe);
                                    }
                                });


                                progressDialog.dismiss();
                                finish();
                                Toast.makeText(AddCarActivity.this, "Bạn đã tạo thành công!", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                Toast.makeText(AddCarActivity.this, "Bạn đã tạo thất bại!", Toast.LENGTH_SHORT).show();
                                Log.e("UPLOAD", exception.getMessage());
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                                progressDialog.setMessage((int)progress + "% uploading...");
                            }
                        });


            }else {
                Toast.makeText(this, "Vui lòng chọn hình ảnh", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == PICK_FROM_CAMERA && data != null){
                imgUri = data.getData();
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                img_car.setImageBitmap(bitmap);
            }

            if (requestCode == PICK_FROM_FILE && data != null){
                imgUri = data.getData();
                img_car.setImageURI(imgUri);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_submit:
                uploadFile();
                break;
        }
    }
}
