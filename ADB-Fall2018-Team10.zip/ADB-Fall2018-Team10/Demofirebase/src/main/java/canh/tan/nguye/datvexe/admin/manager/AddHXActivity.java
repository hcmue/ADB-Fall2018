package canh.tan.nguye.datvexe.admin.manager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.addCar.AddCarActivity;
import canh.tan.nguye.datvexe.data.model.HangXe;
import canh.tan.nguye.datvexe.data.model.Xe;

public class AddHXActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int PICK_FROM_FILE = 1;
    private static final int PICK_FROM_CAMERA = 2;

    FirebaseDatabase database;
    DatabaseReference referenceHX;

    FirebaseStorage storage;
    StorageReference imgRef;

    ImageView imgAdd, imgAddHX;
    EditText edt_name_company,edt_date_establish,edt_so_dien_thoai,edt_adress_company,edt_note;
    Button btn_submit;

    Uri imgUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_hx);

        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        imgRef = storage.getReference();
        referenceHX = database.getReference();

        addControls();
        addEvents();
    }

    private void addEvents() {
        imgAddHX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(AddHXActivity.this, v);
                popupMenu.inflate(R.menu.menu_popup_select_image);
                popupMenu.show();
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.item_file:
                                Intent intent = new Intent();
                                intent.setType("image/*");
                                intent.setAction(Intent.ACTION_GET_CONTENT);
                                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_FROM_FILE);
                                break;
                            case R.id.item_camera:
                                Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                startActivityForResult(takePicture, PICK_FROM_CAMERA);
                                break;
                        }
                        return true;
                    }
                });
            }
        });

        btn_submit.setOnClickListener(this);
    }

    private void addControls() {
        imgAdd = findViewById(R.id.img_car);
        imgAddHX = findViewById(R.id.img_add_car);
        edt_name_company = findViewById(R.id.edt_name_company);
        edt_date_establish = findViewById(R.id.edt_date_establish);
        edt_so_dien_thoai = findViewById(R.id.edt_so_dien_thoai);
        edt_adress_company = findViewById(R.id.edt_adress_company);
        edt_note = findViewById(R.id.edt_note);
        btn_submit = findViewById(R.id.btn_submit);

        edt_date_establish.setText(new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime()));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == PICK_FROM_CAMERA && data != null){
                imgUri = data.getData();
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                imgAdd.setImageBitmap(bitmap);
            }

            if (requestCode == PICK_FROM_FILE && data != null){
                imgUri = data.getData();
                imgAdd.setImageURI(imgUri);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_submit:
                uploadDataFirebase();
                break;
        }
    }

    private void uploadDataFirebase() {
        if (TextUtils.isEmpty(edt_name_company.getText().toString()) ||
                TextUtils.isEmpty(edt_date_establish.getText().toString()) ||
                TextUtils.isEmpty(edt_so_dien_thoai.getText().toString()) ||
                TextUtils.isEmpty(edt_adress_company.getText().toString()) ||
                TextUtils.isEmpty(edt_note.getText().toString())
                ){
            Toast.makeText(this, "Không được bỏ trống", Toast.LENGTH_SHORT).show();
        }else {
            if (imgUri != null){

                final ProgressDialog progressDialog = new ProgressDialog(AddHXActivity.this);
                progressDialog.setTitle("Uploading...");
                progressDialog.show();

                final String idHX = String.valueOf(System.currentTimeMillis());
                final StorageReference riversRef = imgRef.child(idHX +"/" + String.valueOf(System.currentTimeMillis()) + ".jpg");

                riversRef.putFile(imgUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                riversRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        HangXe hangXe = new HangXe.Builder()
                                                .setTenHangXe(edt_name_company.getText().toString())
                                                .setDiaChi(edt_adress_company.getText().toString())
                                                .setImgHinh(uri.toString())
                                                .setNoiDung(edt_note.getText().toString())
                                                .setNgayLap(edt_date_establish.getText().toString())
                                                .setSoDienThoai(edt_so_dien_thoai.getText().toString())
                                                .builder();

                                        database.getReference("HangXe").child(idHX +"").setValue(hangXe);
                                    }
                                });


                                progressDialog.dismiss();
                                finish();
                                Toast.makeText(AddHXActivity.this, "Bạn đã tạo thành công!", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                Toast.makeText(AddHXActivity.this, "Bạn đã tạo thất bại!", Toast.LENGTH_SHORT).show();
                                Log.e("UPLOAD", exception.getMessage());
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                                progressDialog.setMessage((int)progress + "% uploading...");
                            }
                        });


            }else {
                Toast.makeText(this, "Vui lòng chọn hình ảnh", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
