package canh.tan.nguye.datvexe.data.model;

public class Customer {
}
