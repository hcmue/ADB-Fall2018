package canh.tan.nguye.datvexe.data;

import java.util.ArrayList;
import java.util.List;

import canh.tan.nguye.datvexe.data.model.ViTri;

public class SoLuongGhe {
    public static List<ViTri> viTriChoNgoi = new ArrayList<>();
}
