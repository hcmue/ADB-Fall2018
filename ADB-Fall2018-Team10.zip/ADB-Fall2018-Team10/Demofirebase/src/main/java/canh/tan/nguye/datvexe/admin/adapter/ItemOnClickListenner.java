package canh.tan.nguye.datvexe.admin.adapter;

import android.view.View;

public interface ItemOnClickListenner {
    void onClick(View view, int position, boolean isLongClick);
}
