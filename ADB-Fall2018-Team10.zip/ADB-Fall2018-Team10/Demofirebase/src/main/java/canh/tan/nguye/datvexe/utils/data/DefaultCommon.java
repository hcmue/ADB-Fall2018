package canh.tan.nguye.datvexe.utils.data;

import canh.tan.nguye.datvexe.R;

public class DefaultCommon {
    public static final String CUSTOMER = "Khách hàng";
    public static final String TRANSPORT = "Phương tiện";
    public static final String STATISTICS = "Thống kê";
    public static final String SETTING = "Thiết lập";

    public static String[] titleTab = {"KHÁCH HÀNG", "PHƯƠNG TIỆN", "THỐNG KÊ", "THIẾT LẬP"};
    public static int[] imageTab = {R.drawable.ic_customer, R.drawable.ic_car, R.drawable.ic_statistical, R.drawable.ic_setting};
}
