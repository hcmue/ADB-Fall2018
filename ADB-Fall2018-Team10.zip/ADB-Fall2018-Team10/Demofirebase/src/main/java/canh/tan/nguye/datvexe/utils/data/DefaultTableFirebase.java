package canh.tan.nguye.datvexe.utils.data;

public class DefaultTableFirebase {
    public static final String XE = "Xe";
    public static final String USERS = "Users";
    public static final String HANGXE = "HangXe";
    public static final String YEU_CAU = "YeuCau";
}
