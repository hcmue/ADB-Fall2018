package canh.tan.nguye.datvexe.admin.manager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.adapter.ExpandableAdapter;
import canh.tan.nguye.datvexe.data.model.HangXe;

public class SettingActivity extends AppCompatActivity {

    EditText edt_sale;
    Button btn_create_sale;

    String key;
    HangXe currentHX;

    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("HangXe");

        key = getIntent().getStringExtra("HangXeID");
        currentHX = (HangXe) getIntent().getSerializableExtra("HangXe");

        addControls();
        addEvents();
    }

    private void addEvents() {
        edt_sale = findViewById(R.id.edt_sale);
        btn_create_sale = findViewById(R.id.btn_create_sale);

        btn_create_sale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(edt_sale.getText().toString())){
                    if (currentHX != null){
                        HangXe hangXe = new HangXe.Builder()
                                .setSoDienThoai(currentHX.getSoDienThoai())
                                .setNgayLap(currentHX.getNgayLap())
                                .setNoiDung(currentHX.getNoiDung())
                                .setImgHinh(currentHX.getImgHinh())
                                .setDiaChi(currentHX.getDiaChi())
                                .setTenHangXe(currentHX.getTenHangXe())
                                .setSuKien(edt_sale.getText().toString())
                                .builder();

                        reference.child(key).setValue(hangXe).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(SettingActivity.this, "Bạn đã tạo sự kiện cho hãng xe: "
                                        + currentHX.getTenHangXe() + " thành công!", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        });
                    }
                }else {
                    edt_sale.setError("Không được bỏ trống!");
                }
            }
        });
    }

    private void addControls() {

    }
}
