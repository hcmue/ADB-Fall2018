package canh.tan.nguye.datvexe.dialog.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.data.GetHangXeHienTai;
import canh.tan.nguye.datvexe.data.GetViTriXe;
import canh.tan.nguye.datvexe.data.NgayHienTai;
import canh.tan.nguye.datvexe.data.SoLuongGhe;
import canh.tan.nguye.datvexe.data.ViTriHienTai;
import canh.tan.nguye.datvexe.data.model.DatVe;
import canh.tan.nguye.datvexe.data.model.ViTri;
import canh.tan.nguye.datvexe.data.model.YeuCau;

public class DialogDeleteYeuCau extends BaseAdapter {
    private FirebaseDatabase database;
    private DatabaseReference referenceYeuCau;

    private Context context;
    private List<String> list;

    public DialogDeleteYeuCau(Context context, List<String> list) {
        this.context = context;
        this.list = list;
        database = FirebaseDatabase.getInstance();
        referenceYeuCau = database.getReference("YeuCau");
        ViTriHienTai.viTriListChon = new ArrayList<>();

    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @SuppressLint({"ViewHolder", "InflateParams"})
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        final LayoutInflater inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (inflater != null) {
            convertView = inflater.inflate(R.layout.item_position_seat_car, null);
        }

        final TextView txt = convertView.findViewById(R.id.txt_position_seat);
        final LinearLayout layout = convertView.findViewById(R.id.layout_bkg);
        final LinearLayout layout1BG = convertView.findViewById(R.id.layout_bkg_seat);

        final String viTri = list.get(position);

        txt.setText(viTri);
        layout1BG.setBackgroundResource(R.drawable.postion_seat_empty);

        layout1BG.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if (layout1BG.getBackground().getConstantState() == context.getResources().getDrawable(R.drawable.postion_seat_empty).getConstantState()){
                    layout1BG.setBackgroundResource(R.drawable.postion_seat_confirm);
                    ViTriHienTai.viTriListChon.add(viTri);
                    for (String item : ViTriHienTai.viTriListChon){
                        Toast.makeText(context, item + " -- ", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    layout1BG.setBackgroundResource(R.drawable.postion_seat_empty);
                    ViTriHienTai.viTriListChon.remove(viTri);
                    for (String item : ViTriHienTai.viTriListChon){
                        Toast.makeText(context, item + " -- ", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        return convertView;
    }
}
