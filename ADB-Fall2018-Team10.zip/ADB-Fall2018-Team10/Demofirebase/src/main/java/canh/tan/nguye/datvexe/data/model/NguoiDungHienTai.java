package canh.tan.nguye.datvexe.data.model;

import java.io.Serializable;

public class NguoiDungHienTai implements Serializable{
    public static User user;
}
