package canh.tan.nguye.datvexe.data;

public class Status {
    public static final String CHUA_XAC_NHAN = "Chưa xác nhận";
    public static final String XAC_NHAN = "Xác nhận";
    public static final String DA_HUY = "Đã hủy";
}
