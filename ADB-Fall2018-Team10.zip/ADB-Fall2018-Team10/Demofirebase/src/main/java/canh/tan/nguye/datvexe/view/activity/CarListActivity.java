package canh.tan.nguye.datvexe.view.activity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;


import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import java.text.NumberFormat;
import java.util.Locale;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.data.model.Xe;
import canh.tan.nguye.datvexe.utils.data.DefaultTableFirebase;
import canh.tan.nguye.datvexe.view.adapter.ItemOnClickListenner;
import canh.tan.nguye.datvexe.view.adapter.ListCarViewHolder;

public class CarListActivity extends AppCompatActivity {

    //Firebase
    FirebaseDatabase database;
    FirebaseRecyclerOptions<Xe> options;
    FirebaseRecyclerAdapter<Xe, ListCarViewHolder> adapter;

    //Component
    RecyclerView recyclerView;


    //properties
    String idHangXe;
    String tenHangXe;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_list);

        database = FirebaseDatabase.getInstance();
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        getData();

    }

    private void getData() {
        if (idHangXe == null){
            idHangXe = getIntent().getStringExtra("HangXeID");
        }
        if (tenHangXe == null){
            tenHangXe = getIntent().getStringExtra("TenHangXe");
        }

        if (!idHangXe.isEmpty() && idHangXe != null){
            loadList(idHangXe);
        }
    }

    private void loadList(final String idHangXe) {
        recyclerView = findViewById(R.id.recyclerView_CarList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(CarListActivity.this, LinearLayout.VERTICAL, false));

        Query query = database.getReference().child(DefaultTableFirebase.XE).orderByChild("idHX").equalTo(idHangXe);

        options = new FirebaseRecyclerOptions.Builder<Xe>()
                .setQuery(query, Xe.class)
                .build();

        adapter = new FirebaseRecyclerAdapter<Xe, ListCarViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final ListCarViewHolder holder, int position, @NonNull final Xe model) {
                Locale locale = new Locale("en", "US" );
                NumberFormat numberFormat = NumberFormat.getNumberInstance(locale);

                Picasso.get().load(model.getImgHinh()).into(holder.img);
                holder.txtNameCar.setText(model.getTenXe());
                holder.txtFareCar.setText(numberFormat.format(Integer.parseInt(model.getGiaTien())) + " VNĐ");
                holder.txtTimeStartCar.setText(model.getThoiGianBDDi());
                holder.txtDirection.setText(model.getNoiDi() + " - " + model.getNoiDen());
                holder.txtClassifyCar.setText(model.getLoaiXe());
                holder.txtClassifySeat.setText(model.getLoaiChoNgoi());
                holder.txtCarBrand.setText(tenHangXe);

                final String suKien = getIntent().getStringExtra("SUKIEN");
                holder.setListenner(new ItemOnClickListenner() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        Intent intent = new Intent(CarListActivity.this, ChooseSeatActivity.class);
                        intent.putExtra("IDXe", adapter.getRef(position).getKey());
                        intent.putExtra("IDHangXe", idHangXe);
                        intent.putExtra("TenHangXe", tenHangXe);
                        intent.putExtra("XeHienTai", model);
                        intent.putExtra("SUKIEN", suKien);
                        startActivity(intent);
                    }
                });
            }

            @NonNull
            @Override
            public ListCarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new ListCarViewHolder(LayoutInflater.from(CarListActivity.this).inflate(R.layout.item_car, parent, false));
            }
        };

        recyclerView.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
