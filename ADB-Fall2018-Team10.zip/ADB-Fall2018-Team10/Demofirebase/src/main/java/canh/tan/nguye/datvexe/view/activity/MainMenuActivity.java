package canh.tan.nguye.datvexe.view.activity;

import android.annotation.TargetApi;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;

import com.amulyakhare.textdrawable.TextDrawable;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import canh.tan.nguye.datvexe.utils.data.DefaultTableFirebase;
import canh.tan.nguye.datvexe.view.adapter.ItemOnClickListenner;
import canh.tan.nguye.datvexe.view.adapter.MainMenuViewHolder;
import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.login.LoginActivity;
import canh.tan.nguye.datvexe.data.model.HangXe;
import canh.tan.nguye.datvexe.dialog.DialogFilter;

public class MainMenuActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "TAG";
    private static boolean isAdmin = false;

    ImageButton ibtnFilter, ibtnMenu;
    RecyclerView recyclerViewHangXe;
    List<HangXe> hangXeList;

    DialogFilter dialogFilter;

    FirebaseDatabase database;
    DatabaseReference referenceHangXe;
    FirebaseRecyclerOptions<HangXe> options;
    FirebaseRecyclerAdapter<HangXe, MainMenuViewHolder> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        database = FirebaseDatabase.getInstance();
        referenceHangXe = database.getReference("HangXe");

        initAdmin();
        initDialogs();
        addControls();
        addEvents();
    }

    private void initDialogs() {
        dialogFilter = new DialogFilter(this);
    }

    private void initAdmin() {
        //isAdmin = CurrentUser.verifyUser();
    }

    private void initDataFromFirebase() {
        Query query = database.getReference().child(DefaultTableFirebase.HANGXE);

        options = new FirebaseRecyclerOptions.Builder<HangXe>()
                .setQuery(query, HangXe.class)
                .build();

        adapter = new FirebaseRecyclerAdapter<HangXe, MainMenuViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull MainMenuViewHolder holder, int position, @NonNull final HangXe model) {

                Picasso.get().load(model.getImgHinh()).into(holder.img);
                holder.txtTenHang.setText(model.getTenHangXe());
                holder.txtDiaChi.setText(model.getDiaChi());
                holder.txtNoiDung.setText(model.getNoiDung());

                if (holder.txtTenHang.length() >= 50){
                    String temp = holder.txtTenHang.getText().toString();
                    holder.txtTenHang.setText(temp.substring(0, 50) + "...");
                }

                if (holder.txtDiaChi.length() >= 50){
                    String temp = holder.txtDiaChi.getText().toString();
                    holder.txtDiaChi.setText(temp.substring(0, 50) + "...");
                }

                if (holder.txtNoiDung.length() >= 100){
                    String temp = holder.txtNoiDung.getText().toString();
                    holder.txtNoiDung.setText(temp.substring(0, 100) + "...");
                }

                holder.setListenner(new ItemOnClickListenner() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        Intent carList = new Intent(MainMenuActivity.this, CarListActivity.class);
                        carList.putExtra("HangXeID", adapter.getRef(position).getKey());
                        carList.putExtra("TenHangXe", model.getTenHangXe());
                        carList.putExtra("SUKIEN", model.getSuKien());
                        startActivity(carList);

                    }
                });
            }

            @NonNull
            @Override
            public MainMenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new MainMenuViewHolder(LayoutInflater.from(MainMenuActivity.this).inflate(R.layout.item_hang_xe, parent, false));
            }
        };

        recyclerViewHangXe.setAdapter(adapter);
        //recyclerViewHangXe.setAdapter(alphaAdapter);
        //adapter.notifyDataSetChanged();
    }

    private void addEvents() {
        ibtnFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogFilter.show();
            }
        });

        ibtnMenu.setOnClickListener(MainMenuActivity.this);
    }

    private void addControls() {
        ibtnFilter = findViewById(R.id.ibtnFilter_MainMenu);
        ibtnMenu = findViewById(R.id.ibtnMenu_MainMenu);
        recyclerViewHangXe = findViewById(R.id.recyclerView_MainMenu);
        recyclerViewHangXe.setHasFixedSize(true);
        recyclerViewHangXe.setLayoutManager(new LinearLayoutManager(this, LinearLayout.VERTICAL, false));


        hangXeList = new ArrayList<>();

        initDataFromFirebase();
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.ibtnMenu_MainMenu:
                PopupMenu popupMenu = new PopupMenu(MainMenuActivity.this, v);
                popupMenu.inflate(R.menu.popup_menu);
                popupMenu.show();
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.menu_item_management:
                                if(isAdmin){
                                    Intent intent = new Intent(MainMenuActivity.this, LoginActivity.class);
                                    Bundle bundleAnim = ActivityOptions.makeCustomAnimation(
                                            MainMenuActivity.this,
                                            R.anim.anim_left_right_1,
                                            R.anim.anim_left_right_2)
                                            .toBundle();
                                    startActivity(intent, bundleAnim);
                                }else {
                                    Intent intent = new Intent(MainMenuActivity.this, LoginActivity.class);
                                    Bundle bundleAnim = ActivityOptions.makeCustomAnimation(
                                            MainMenuActivity.this,
                                            R.anim.anim_left_right_1,
                                            R.anim.anim_left_right_2)
                                            .toBundle();
                                    startActivity(intent, bundleAnim);
                                }
                                break;
                            case R.id.menu_item_help:
                                break;
                        }
                        return false;
                    }
                });
                break;
        }
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Đóng ứng dụng")
                .setMessage("Bạn có chắc chắn muốn đóng ứng dụng này lại không?")
                .setPositiveButton("Đóng lại", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent a = new Intent(Intent.ACTION_MAIN);
                        a.addCategory(Intent.CATEGORY_HOME);
                        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(a);
                    }
                })
                .setNegativeButton("Quay lại", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
    }
}
