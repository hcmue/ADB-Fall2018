package canh.tan.nguye.datvexe.view.adapter;

import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.data.GetHangXeHienTai;
import canh.tan.nguye.datvexe.data.GetViTriXe;
import canh.tan.nguye.datvexe.data.NgayHienTai;
import canh.tan.nguye.datvexe.data.SoLuongGhe;
import canh.tan.nguye.datvexe.data.model.DatVe;
import canh.tan.nguye.datvexe.data.model.ViTri;
import canh.tan.nguye.datvexe.data.model.YeuCau;
import canh.tan.nguye.datvexe.utils.convertData.ConvertDateFormatToString;


public class ChooseSeatAdapter extends BaseAdapter {

    private FirebaseDatabase database;
    private DatabaseReference referenceYeuCau;

    private Context context;
    private List<ViTri> list;


    public ChooseSeatAdapter(Context context, List<ViTri> list) {
        this.context = context;
        this.list = list;
        database = FirebaseDatabase.getInstance();
        referenceYeuCau = database.getReference("YeuCau");
        SoLuongGhe.viTriChoNgoi = new ArrayList<>();

    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final View view = convertView;

        final LayoutInflater inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.item_position_seat_car, null);

        final TextView txt = convertView.findViewById(R.id.txt_position_seat);
        final LinearLayout layout = convertView.findViewById(R.id.layout_bkg);
        final LinearLayout layout1BG = convertView.findViewById(R.id.layout_bkg_seat);

        final ViTri viTri = list.get(position);

        txt.setText(viTri.getTenViTri());
        layout1BG.setBackgroundResource(R.drawable.postion_seat_empty);

        //Toast.makeText(context, date, Toast.LENGTH_SHORT).show();



        database.getReference().child("YeuCau").orderByChild("idhangXe").equalTo(GetHangXeHienTai.idHangXe)
                .addValueEventListener(new ValueEventListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot item : dataSnapshot.getChildren()){
                            if (item.exists()){
                                //Log.i("INFO",item.getValue(YeuCau.class).getTenNguoiNhan() );
                                YeuCau  yeuCau= item.getValue(YeuCau.class);


                                if (yeuCau != null) {
                                    if (yeuCau.getThongTinDatVe().getIdxe().equals(GetHangXeHienTai.idXe)){
                                        if (yeuCau.getThongTinDatVe().getNgayDat().equals(NgayHienTai.date)){
                                            //Log.i("NGAY", NgayHienTai.date + " - " + yeuCau.getThongTinDatVe().getNgayDat());
                                            String[] temp = yeuCau.getThongTinDatVe().getChoNgoi().split(",");
                                            for (int i = 0; i < GetViTriXe.getViTri().size(); i++){
                                                for (int j = 0; j < temp.length; j++) {
                                                    if (temp[j].equals(viTri.getTenViTri())){
                                                        //Log.i("NGAY", NgayHienTai.date + " - " + yeuCau.getThongTinDatVe().getNgayDat());
                                                        Log.i("NGAY", NgayHienTai.date + " - " + yeuCau.getThongTinDatVe().getNgayDat());

                                                        //view.setEnabled(false);
                                                        layout1BG.setEnabled(false);
                                                        layout.setEnabled(false);
                                                        layout1BG.setBackgroundResource(R.drawable.postion_seat_not_confirm);
                                                        Log.i("VITRI", yeuCau.getThongTinDatVe().getChoNgoi());
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(context, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        layout1BG.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if (layout1BG.getBackground().getConstantState() == context.getResources().getDrawable(R.drawable.postion_seat_empty).getConstantState()){
                    layout1BG.setBackgroundResource(R.drawable.postion_seat_confirm);
                    SoLuongGhe.viTriChoNgoi.add(viTri);
                }else {
                    layout1BG.setBackgroundResource(R.drawable.postion_seat_empty);
                    SoLuongGhe.viTriChoNgoi.remove(viTri);
                }
            }
        });
        return convertView;
    }
}
