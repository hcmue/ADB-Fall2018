package canh.tan.nguye.datvexe.data;

public class NgayHienTai {
    public static String date;
}
