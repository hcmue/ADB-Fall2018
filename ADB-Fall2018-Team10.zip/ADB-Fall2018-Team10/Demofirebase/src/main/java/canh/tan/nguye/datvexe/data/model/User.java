package canh.tan.nguye.datvexe.data.model;

import java.io.Serializable;

public class User implements Serializable{
    private String address;
    private String password;


    public User() {
    }

    public User(Builder builder) {
        this.address = builder.address;
        this.password = builder.password;
    }


    public String getAddress() {
        return address;
    }

    public String getPassword() {
        return password;
    }


    public static class Builder{
        private String address;
        private String password;


        public Builder() {
        }

        public Builder( String address,String password) {
            this.address = address;
            this.password = password;

        }



        public Builder setAddress(String address) {
            this.address = address;
            return this;
        }

        public Builder setPassword(String password) {
            this.password = password;
            return this;
        }

        public User builder(){
            return new User(this);
        }
    }
}
