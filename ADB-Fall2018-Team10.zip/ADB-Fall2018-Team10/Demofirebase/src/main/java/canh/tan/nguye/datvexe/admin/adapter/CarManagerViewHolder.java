package canh.tan.nguye.datvexe.admin.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import canh.tan.nguye.datvexe.R;

public class CarManagerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public ImageView car_img;
    public TextView car_txt_name, car_txt_route,car_txt_time_start,car_txt_fare;
    public ImageButton delete_car,ibtnEditCar_Manager;

    private ItemOnClickListenner listenner;

    public CarManagerViewHolder setListenner(ItemOnClickListenner listenner) {
        this.listenner = listenner;
        return this;
    }

    public CarManagerViewHolder(View itemView) {
        super(itemView);
        car_img = itemView.findViewById(R.id.car_img);
        car_txt_name = itemView.findViewById(R.id.car_txt_name);
        car_txt_route = itemView.findViewById(R.id.car_txt_route);
        car_txt_time_start = itemView.findViewById(R.id.car_txt_time_start);
        car_txt_fare = itemView.findViewById(R.id.car_txt_fare);
        delete_car = itemView.findViewById(R.id.delete_car);
        ibtnEditCar_Manager = itemView.findViewById(R.id.ibtnEditCar_Manager);

        itemView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.delete_car:
                listenner.onClick(v, getAdapterPosition(), false);
                break;
            case R.id.ibtnEditCar_Manager:
                listenner.onClick(v, getAdapterPosition(), false);
                break;
        }
    }
}
