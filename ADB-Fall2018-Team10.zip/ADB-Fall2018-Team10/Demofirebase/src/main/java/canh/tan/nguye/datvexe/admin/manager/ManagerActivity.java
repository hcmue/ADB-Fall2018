package canh.tan.nguye.datvexe.admin.manager;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import canh.tan.nguye.datvexe.R;
import canh.tan.nguye.datvexe.admin.adapter.PagerAdapter;
import canh.tan.nguye.datvexe.admin.login.LoginActivity;

public class ManagerActivity extends AppCompatActivity {

    private ViewPager mViewPager;
    PagerAdapter adapter;
    TabLayout tabLayout;

    Toolbar toolbar;
    LinearLayout llayout_add_car;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);
        llayout_add_car = findViewById(R.id.llayout_add_car);
        addCOntrol();
        addEvents();
    }

    private void addEvents() {
        llayout_add_car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ManagerActivity.this, AddHXActivity.class);
                startActivity(intent);
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(ManagerActivity.this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Đăng xuất")
                        .setMessage("Bạn có chắc chắn muốn đăng xuất không?")
                        .setPositiveButton("Đăng xuất", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(ManagerActivity.this, LoginActivity.class);
                                Bundle bundle = ActivityOptions.makeCustomAnimation(ManagerActivity.this, R.anim.anim_right_left_1, R.anim.anim_right_left_2).toBundle();
                                startActivity(intent, bundle);
                                finish();
                            }
                        })
                        .setNegativeButton("Quay lại", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }).show();
            }
        });
    }

    private void addCOntrol() {
        //set toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        tabLayout = (TabLayout) findViewById(R.id.tabs);

        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        adapter = new PagerAdapter(getSupportFragmentManager(), ManagerActivity.this);
        mViewPager.setAdapter(adapter);
        mViewPager.setCurrentItem(0, true);


        /*//set onClickChangeListenner Between viewpager and tabLayout
        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));*/

        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#3A6073"));
        tabLayout.setSelectedTabIndicatorHeight(5);

        tabLayout.setupWithViewPager(mViewPager);

        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            View v = adapter.getTabView(i);
            tabLayout.getTabAt(i).setCustomView(v);
        }

    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(ManagerActivity.this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Đăng xuất")
                .setMessage("Bạn có chắc chắn muốn đăng xuất không?")
                .setPositiveButton("Đăng xuất", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(ManagerActivity.this, LoginActivity.class);
                        Bundle bundle = ActivityOptions.makeCustomAnimation(ManagerActivity.this, R.anim.anim_right_left_1, R.anim.anim_right_left_2).toBundle();
                        startActivity(intent, bundle);
                        finish();
                    }
                })
                .setNegativeButton("Quay lại", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
    }
}
