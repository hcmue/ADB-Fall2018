﻿---Ho va ten: Tran Thi Thu 
---MSSV: 41.01.104.126
---Ca thi: Thu ba

--Cau1
-- Bo sung lenh Go de Script chay lien tuc.

CREATE DATABASE QLBD

USE QLBD

CREATE TABLE BANG
(
	MaBang NVARCHAR(8) PRIMARY KEY,
	LoaiBang NVARCHAR(1),
	TenTapPhim NVARCHAR(50),
	TinhTrang NVARCHAR(1),
)
CREATE TABLE CTTHUE
(
	MaPhieu NVARCHAR(4),
	MaBang NVARCHAR(8),
	NgayTra DATETIME,
	DonGia DECIMAL,
	ThanhTien DECIMAL,
	PRIMARY KEY(MaPhieu, MaBang)
)
CREATE TABLE DMKH
(
	MaKH NVARCHAR(5) PRIMARY KEY,
	LoaiKH NVARCHAR(1),
	TenKH NVARCHAR(50),
	DiaChi NVARCHAR(50),
	DienThoai NVARCHAR(10),
	SoCMND NVARCHAR(9),
)
CREATE TABLE PHIEUTHUE
(
	MaPhieu NVARCHAR(4) PRIMARY KEY,
	NgayThue DATETIME,
	MaKH NVARCHAR(5),
	CoCMND BIT,
	TienDatCoc DECIMAL,
)
ALTER TABLE CTTHUE
	ADD CONSTRAINT fk_MaBang FOREIGN KEY(MaBang) REFERENCES BANG(MaBang) 
ALTER TABLE CTTHUE
	ADD CONSTRAINT fk_MaPhieu FOREIGN KEY(MaPhieu) REFERENCES PHIEUTHUE(MaPhieu)
ALTER TABLE PHIEUTHUE
	ADD CONSTRAINT fk_MaKH FOREIGN KEY(MaKH) REFERENCES DMKH(MaKH)

INSERT INTO BANG(MaBang, LoaiBang, TenTapPhim, TinhTrang)
VALUES
('HK003_01','B',N'Ngọa hổ tàng long - Tập 1','M'),
('HQ002_01','B',N'Công ty luật - Tập 1','R'),
('MY001_00','D',N'Don''t Say a word','R'),
('MY002_00','D',N'Con gái tướng quân','M'),
('VN001_00','B',N'Cảnh sát hình sự','R'),
('VN002_00','B',N'Chuột','R')
INSERT INTO DMKH(MaKH, LoaiKH, TenKH, DiaChi, DienThoai, SoCMND)
VALUES
('H0001','Q',N'Lưu Dân Huy',N'110/26 Ông Ích Khiêm','0903927887',NULL),
('T0001','K',N'Nguyễn Ánh Tuyết',N'11/1 Vườn Chuối','8325218','258456357'),
('T0003','Q',N'Nguyễn A Thường',N'323/14 Hùng Vương','9603254',NULL)
INSERT INTO PHIEUTHUE(MaPhieu, NgayThue, MaKH, CoCMND, TienDatCoc)
VALUES
('C001','09/02/2002','T0001','False','20000'),
('C002','09/02/2002','H0001','True','0'),
('S001','09/01/2002','T0003','False','15000'),
('T002','09/02/2002','T0001','True','0'),
('T003','09/02/2002','T0003','True','0')
INSERT INTO CTTHUE(MaPhieu, MaBang, NgayTra, DonGia, ThanhTien)
VALUES
('C001','VN002_00','09/04/2002','2500','5000'),
('C002','VN001_00','09/03/2002','2500','2500'),
('S001','HQ002_01','09/02/2002','2500','2500'),
('T002','MY001_00','09/04/2002','5000','10000'),
('T003','HK003_01',NULL,'2500','0'),
('T003','MY002_00',NULL,'4000','0')

--Cau2
---1  = 'True'   De bai co du lieu, viet dieu kien = 'True' se ra ket qua
SELECT PHIEUTHUE.MaPhieu, DMKH.TenKH, PHIEUTHUE.NgayThue
FROM PHIEUTHUE INNER JOIN DMKH ON PHIEUTHUE.MaKH=DMKH.MaKH
WHERE PHIEUTHUE.CoCMND like'True'

---2
SELECT TenKH AS 'TÊN KHÁCH HÀNG', (CASE LoaiKH WHEN 'Q' THEN 'Khách quen' ELSE 'Khác thường' END) AS 'LOẠI KHÁCH' , 
DiaChi AS 'ĐỊA CHỈ'
FROM DMKH 
WHERE TenKH LIKE'%A%'

---3 sai  phai  dung truy van long Select ....not in (Select...)

SELECT  DMKH.TenKH, DMKH.Diachi, DMKH.Dienthoai
FROM DMKH INNER JOIN PHIEUTHUE ON DMKH.MaKH= PHIEUTHUE.MaKH 
			INNER JOIN CTTHUE ON PHIEUTHUE.MaPhieu=CTTHUE.MaPhieu 
				INNER JOIN BANG ON CTTHUE.MaBang=BANG.MaBang
WHERE BANG.TenTapPhim not like 'Ngọa hổ tàng long - Tập 1'
GROUP BY  DMKH.TenKH,DMKH.Diachi,DMKH.Dienthoai

---4
SELECT DMKH.MaKH,LoaiKH,TenKH,COUNT(PHIEUTHUE.MaPhieu) AS 'Số lần thuê'
FROM DMKH INNER JOIN PHIEUTHUE ON DMKH.MAKH = PHIEUTHUE.MaKH
GROUP BY DMKH.MaKH,LoaiKH,TenKH

