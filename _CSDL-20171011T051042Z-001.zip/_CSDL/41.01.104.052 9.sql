﻿-- Thieu thong tin ca nhan nhu yeu cau de bai
-- Bo sung lenh Go de Script chay lien tuc tu tren xuong
-- De bai ra chung cho Access va SQL nen kieu so thuc phai la Double/Real khong phai Int
-- Cau 2.2 yeu cau de bai liet ke thuoc tinh day du
-- Cau 2.4 ok, nen tach thanh 3 cap cho de xem

--use master          bo lenh thua
--drop database LINH  bo lenh thua 

--CAU 1
create database LINH

use LINH

create table KHACHHANG(
	MAKH	char(3),
	TENKH	Nvarchar(30),
	DIACHI	Nvarchar(30),
	SODT	varchar(12)

	constraint MAKH_PK primary key(MAKH),
)

create table DMHH(
	MAHH	char(4),
	TENHH	Nvarchar(30),
	DVT		Nvarchar(10),
	TRIGIA	int

	constraint MAHH_PK primary key(MAHH),
)

create table HOPDONG(
	SOHD		char(5),
	NGAYHD		datetime,
	MAKH		char(3),
	MAHH		char(4),
	KYHAN		int,
	SLMUA		int,
	TRATRUOC	int,
	TRAHANGTHANG int

	constraint SOHD_PK primary key(SOHD),
	constraint MAKH_FK foreign key(MAKH) references KHACHHANG(MAKH),
	constraint MAHH_FK foreign key(MAHH) references DMHH(MAHH)
)

create table TRAGOP(
	KYTRA	char(7),
	SOHD	char(5),
	SOTIEN	int

	constraint KYTRA_SOHD_PK primary key(KYTRA,SOHD),
	constraint SOHD_FK foreign key (SOHD) references HOPDONG(SOHD)
)

insert into KHACHHANG(MAKH,TENKH,DIACHI,SODT) values
	('A01',N'Nguyễn Thu Yến',N'84A An Dương Vương','8353396'),
	('A02',N'Cty Phú Mỹ Hưng',N'Khu CX Tân Thuận','8721903'),
	('A03',N'Cty Dược TP (SAPHACO)',N'Hàm Tân Q4','8300328')

insert into DMHH(MAHH,TENHH,DVT,TRIGIA) values
	('DH01',N'Máy lạnh 2 cục TOSHIBA',N'Cái',11500000),
	('TL01',N'Tủ lạnh TOSHIBA',N'Cái',3500000),
	('TL02',N'Tủ lạnh HITACHI',N'Cái',6000000)

insert into HOPDONG(SOHD,NGAYHD,MAKH,MAHH,KYHAN,SLMUA,TRATRUOC,TRAHANGTHANG) values
	('HD001','08/01/2016','A03','TL01',3,2,1000000,0),
	('HD002','08/05/2016','A01','TL02',6,10,30000000,0)

insert into TRAGOP(KYTRA,SOHD,SOTIEN) values
	('09/2003','HD001',2000000),
	('09/2003','HD002',5000000),
	('10/2003','HD001',2000000)

--CAU 2.1
select KHACHHANG.MAKH, TENKH, DIACHI, SODT
from KHACHHANG, HOPDONG
where KHACHHANG.MAKH=HOPDONG.MAKH and month(NGAYHD)=8 and year(NGAYHD)=2016
order by KHACHHANG.MAKH ASC

--CAU 2.2
select *
from DMHH
where TENHH like N'%tủ%'

--CAU 2.3
select SOHD, TENKH
from HOPDONG, KHACHHANG
where HOPDONG.MAKH=KHACHHANG.MAKH and SOHD not in(
	select SOHD
	from TRAGOP
)

--CAU 2.4
select KHACHHANG.MAKH, TENKH, DIACHI, SODT, SLMUA
from KHACHHANG, HOPDONG
where KHACHHANG.MAKH=HOPDONG.MAKH and SLMUA >= ALL(
	select SLMUA
	from HOPDONG
)