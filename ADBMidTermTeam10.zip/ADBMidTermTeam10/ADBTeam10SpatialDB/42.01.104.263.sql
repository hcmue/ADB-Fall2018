﻿CREATE DATABASE ADBTeam10SpatialDB
GO
USE ADBTeam10SpatialDB
GO
Create table ADBTeam10SpatialDB
(
Mau nvarchar(10),
Ma char(5),
YNghia nvarchar(20),
LuongNuoc float,
DoanhThu float,
ViTri geometry,
)
go
insert into ADBTeam10SpatialDB(Mau, Ma, YNghia, LuongNuoc, DoanhThu, ViTri) values
(N'Xám', 'M7', N'Trồng lúa', 45000, 250.6, geometry::STGeomFromText('POLYGON ((-7 0, -5 1, -7 2, 4 2, 2 1, 4 0, -7 0))', 0)),
(N'Nâu', 'M8', N'Trồng cây ăn quả', 30000 , 350.4, geometry::STGeomFromText('POLYGON ((0 2, 3 9, 8 6, 5 7, 4 2, 0 2))', 0)),
(N'Tím', 'M9', N'Trồng rau', 60000, 450.5 , geometry::STGeomFromText('POLYGON ((4 2, 5 7, 8 6, 9 1, 4 2))', 0)),
(N'Hồng', 'M10', N'Trồng Cỏ', 55000, 150.5 , geometry::STGeomFromText('POLYGON ((7 -5, 4 0, 2 1, 4 2, 9 1, 8 -4, 7 -5))', 0))
select *from ADBTeam10SpatialDB;
----Câu a
select Mau, Ma, YNghia, ViTri.STArea() as DienTich, ViTri.STArea()*0.0001*LuongNuoc as LuongNuocTuoiCan
from ADBTeam10SpatialDB
--- Câu b
select top 1 Mau, Ma, YNghia, ViTri.STArea() as DienTich
from ADBTeam10SpatialDB
order by DienTich DESC
--- Câu c
DECLARE @Kenh geometry=geometry::STGeomFromText('POLYGON((1 -5, 1 9, 4 9, 4 -5, 1 -5))',0)
select Mau, ViTri.STIntersection(@Kenh) as DienTichBiCat
from ADBTeam10SpatialDB

